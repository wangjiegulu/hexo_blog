---
title: android真机调试时无法显示logcat信息的解决办法
tags: []
date: 2012-05-09 15:24:00
---

**android真机调试时无法显示logcat信息的解决办法：**

<span>window--&gt;show view--&gt;android-&gt;devices，</span>

<span>打开devices，点击右边的截屏图片的按钮。等到出现截图的时候，logcat就出来信息了！</span>