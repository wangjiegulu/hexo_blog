---
title: Learn RxJava
tags: []
date: 2015-05-11 19:33:00
---

Learn&nbsp;RxJava

　　[http://reactivex.io/documentation/operators.html](http://reactivex.io/documentation/operators.html)

<span style="line-height: 1.5;">　　</span>[https://github.com/ReactiveX/RxJava/wiki/The-RxJava-Android-Module](https://github.com/ReactiveX/RxJava/wiki/The-RxJava-Android-Module)

　　[https://github.com/ReactiveX/RxJava](https://github.com/ReactiveX/RxJava)

&nbsp;

*   [How the New York Times is building its Android app with Groovy/RxJava](http://open.blogs.nytimes.com/2014/08/18/getting-groovy-with-reactive-android/?_php=true&amp;_type=blogs&amp;_php=true&amp;_type=blogs&amp;_r=1&amp;)&nbsp;by Mohit Pandey
*   [Functional Reactive Programming on Android With RxJava](http://mttkay.github.io/blog/2013/08/25/functional-reactive-programming-on-android-with-rxjava/)&nbsp;and&nbsp;[Conquering concurrency - bringing the Reactive Extensions to the Android platform](https://speakerdeck.com/mttkay/conquering-concurrency-bringing-the-reactive-extensions-to-the-android-platform)&nbsp;by Matthias K&auml;ppler
*   [Learning RxJava for Android by example](https://github.com/kaushikgopal/Android-RxJava)&nbsp;by Kaushik Gopal
*   [Top 7 Tips for RxJava on Android](http://blog.futurice.com/top-7-tips-for-rxjava-on-android)&nbsp;and&nbsp;[Rx Architectures in Android](http://www.slideshare.net/TimoTuominen1/rxjava-architectures-on-android-8-android-livecode-32531688)&nbsp;by Timo Tuominen
*   [FRP on Android](http://slid.es/yaroslavheriatovych/frponandroid)&nbsp;by Yaroslav Heriatovych
*   [Rx for .NET and RxJava for Android](http://blog.futurice.com/tech-pick-of-the-week-rx-for-net-and-rxjava-for-android)&nbsp;by Olli Salonen
*   [RxJava in Xtend for Android](http://blog.futurice.com/android-development-has-its-own-swift)&nbsp;by Andre Medeiros
*   [RxJava and Xtend](http://mnmlst-dvlpr.blogspot.de/2014/07/rxjava-and-xtend.html)&nbsp;by Stefan Oehme
*   Grokking RxJava,&nbsp;[Part 1: The Basics](http://blog.danlew.net/2014/09/15/grokking-rxjava-part-1/),&nbsp;[Part 2: Operator, Operator](http://blog.danlew.net/2014/09/22/grokking-rxjava-part-2/),&nbsp;[Part 3: Reactive with Benefits](http://blog.danlew.net/2014/09/30/grokking-rxjava-part-3/),&nbsp;[Part 4: Reactive Android](http://blog.danlew.net/2014/10/08/grokking-rxjava-part-4/)&nbsp;- published in Sep/Oct 2014 by Daniel Lew
*   [http://blog.dreamtobe.cn/2289.html](http://blog.dreamtobe.cn/2289.html)（中文）