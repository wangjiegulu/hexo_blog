---
title: mysql 基本使用教程(源于网络)
tags: []
date: 2012-07-08 17:19:00
---

<dl><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.1\. 连接与断开服务器</span></span></span></dt><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.2\. 输入查询</span></span></span></dt><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.3\. 创建并使用数据库</span></span></span></dt><dd><dl><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.1\. 创建并选择数据库</span></span></span></dt><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.2\. 创建表</span></span></span></dt><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.3\. 将数据装入表中</span></span></span></dt><dt><span class="section"><span style="color: #0000ff;"><span style="text-decoration: underline;">3.3.4\. 从表检索信息</span></span></span></dt></dl></dd><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.4\. 获得数据库和表的信息</span></span></span></dt><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.5\. 在批处理模式**下使用my**sql</span></span></span></dt><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.6\. 常用查询的例子</span></span></span></dt><dd><dl><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.1\. 列的最大值</span></span></span></dt><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.2\. 拥有某个列的最大值的行</span></span></span></dt><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.3\. 列的最大值：按组</span></span></span></dt><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.4\. 拥有某个字段的组间最大值的行</span></span></span></dt><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.5\. 使用用户变量</span></span></span></dt><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.6\. 使用外键</span></span></span></dt><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.7\. 根据两个键搜索</span></span></span></dt><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.8\. 根据天计算访问量</span></span></span></dt><dt><span class="section"><span style="color: #0000ff;"><span style="text-decoration: underline;">3.6.9\. 使用AUTO_INCREMENT</span></span></span></dt></dl></dd><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.7\. 孪生项目的查询</span></span></span></dt><dd><dl><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.7.1\. 查找所有未分发的孪生项</span></span></span></dt><dt><span class="section"><span style="color: #0000ff;"><span style="text-decoration: underline;">3.7.2\. 显示孪生对状态的表</span></span></span></dt></dl></dd><dt><span class="section"><span style="text-decoration: underline;"><span style="color: #0000ff;">3.8\. 与Apache一起使用MySQL</span></span></span></dt></dl>

<a class="indexterm" name="id2732856"></a><a class="indexterm" name="id2732863"></a><a class="indexterm" name="id2732873"></a><a class="indexterm" name="id2732883"></a>

本章通过演示如何使用**mysql**客户程序创造和使用一个简单的数据库，提供一个MySQL的入门教程。**mysql**（有时称为&ldquo;终端监视器&rdquo;或只是&ldquo;监视&rdquo;）是一个交互式程序，允许你连接一个MySQL服务器，运行查询并察看结果。**mysql**可以用于批模式：你预先把查询放在一个文件中，然后告诉**mysql**执行文件的内容。本章将介绍使用**mysql**的两个方法。

要想查看由**mysql**提供的选择项目表，可以用--help选项来调用：

<pre>shell&gt; **mysql --help**</pre>

本章假定**mysql**已经被安装在你的机器上，并且有一个MySQL服务器可以连接。否则，请联络MySQ**L**管理员。（如果_你_是管理员，则需要查阅本手册的其它章节，例如[<span style="text-decoration: underline;"><span style="color: #0000ff;">第5章：</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/database-administration.html)[_<span style="text-decoration: underline;"><span style="color: #0000ff;">数据库管理</span></span>_](http://dev.mysql.com/doc/refman/5.1/zh/database-administration.html "Chapter&nbsp;5.&nbsp;Database Administration")。）

本章描述建立和使用一个数据库的全过程。如果你仅仅对访问一个已经存在的数据库感兴趣，可以跳过描述怎样创建数据库及它所包含的表的章节。

由于本章是一个教程，省略了许多细节。关于这里所涉及的主题的详细信息，请查阅本手册的相关章节。

<div class="section">
<div class="titlepage">

## <a name="connecting-disconnecting"></a>3.1.&nbsp;连接与断开服务器

</div>
<a class="indexterm" name="id2732995"></a><a class="indexterm" name="id2733005"></a><a class="indexterm" name="id2733016"></a><a class="indexterm" name="id2733026"></a></div>
<div class="section">
<div class="titlepage">为了连接服务器，当调用**mysql**时，通常需要提供一个MySQL用户名并且很可能需要一个 密码。如果服务器运行在登录服务器之外的其它机器上，还需要指定主机名。联系管理员以找出进行连接所使用的参数&nbsp;(即，连接的主机、用户名和使用的密码)。知道正确的参数后，可以按照以下方式进行连接：
<pre>shell&gt; **mysql -h _host_ -u _user_ -p**</pre>
<pre>Enter password: ************</pre>

host和user分别代表MySQL服务器运行的主机名和MySQL账户用户名。设置时替换为正确的值。********&nbsp;代表你的密码；当**mysql**显示Enter password:提示时输入它。

如果有效，你应该看见mysql&gt;提示符后的一些介绍信息：

<pre>shell&gt; **mysql -h _host_ -u _user_ -p**</pre>
<pre>Enter password: ************</pre>
<pre>Welcome to the MySQL monitor.&nbsp; Commands end with ; or /g.</pre>
<pre>Your MySQL connection id is 25338 to server version: 5.1.2-alpha-standard</pre>
<pre>&nbsp;</pre>
<pre>Type 'help;' or '/h' for help. Type '/c' to clear the buffer.</pre>
<pre>&nbsp;</pre>
<pre>mysql&gt;</pre>

mysql&gt;&nbsp;提示符告诉你mysql准备为你输入命令。

一些**<span>MySQL</span>**安装允许用户以匿名（未命名）用户连接到本地主机上运行的服务器。如果你的机器是这种情况，你应该能不带任何选项地调用**mysql**与该服务器连接：

<pre>shell&gt; **mysql**</pre>

成功地连接后，可以在mysql&gt;提示下输入QUIT&nbsp;(或/q)随时退出：

<pre>mysql&gt; **QUIT**</pre>
<pre>Bye</pre>

在Unix中，也可以按control-D键断开服务器。

在下列章节的大多数例子都假设你连接到了服务器。由mysql&gt;提示指明。

## <a name="entering-queries"></a>3.2.&nbsp;输入查询

</div>
<a class="indexterm" name="id2733209"></a><a class="indexterm" name="id2733219"></a><a class="indexterm" name="id2733229"></a>

确保你连接上了服务器，如在先前的章节讨论的。连接上服务器并布代表选择了任何数据库，但这样就可以了。知道关于如何查询的基本知识，比马上跳至创建表、给他们装载数据并且从他们检索数据更重要。本节描述输入命令的基本原则，使用几个查询，你能尝试了解**mysql**是如何工作的。

这是一个简单的命令，要求服务器告诉它的版本号和当前日期。在mysql&gt;提示输入如下命令并按回车键：

<pre>mysql&gt; **SELECT VERSION(), CURRENT_DATE;**</pre>
<pre>+-----------------+--------------+</pre>
<pre>| VERSION()&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | CURRENT_DATE |</pre>
<pre>+-----------------+--------------+</pre>
<pre>| 5.1.2-alpha-log | 2005-10-11&nbsp;&nbsp; |</pre>
<pre>+-----------------+--------------+</pre>
<pre>1 row in set (0.01 sec)</pre>
<pre>mysql&gt;</pre>

这询问说明**mysql**的几个方面:

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;一个命令通常由SQL语句组成，随后跟着一个分号。（有一些例外不需要分号。早先提到的QUIT是一个例子。后面我们将看到其它的例子。）

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;当发出一个命令时，**mysql**将它发送给服务器并显示执行结果，然后显示另一个mysql&gt;显示它准备好接受其它命令。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**mysql**用表格(行和列)方式显示查询输出。第一行包含列的标签，随后的行是查询结果。通常，列标签是你取自数据库表的列的名字。如果你正在检索一个表达式而非表列的值(如刚才的例子)，**mysql**用表达式本身标记列。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**mysql**显示返回了多少行，以及查询花了多长时间，它给你提供服务器性能的一个大致概念。因为他们表示时钟时间(不是&nbsp;CPU&nbsp;或机器时间)，并且因为他们受到诸如服务器负载和网络延时的影响，因此这些值是不精确的。（为了简洁，在本章其它例子中不再显示&ldquo;集合中的行&rdquo;。）

能够以大小写输入关键词。下列查询是等价的：

<pre>mysql&gt; **SELECT VERSION(), CURRENT_DATE;**</pre>
<pre>mysql&gt; **select version(), current_date;**</pre>
<pre>mysql&gt; **SeLeCt vErSiOn(), current_DATE;**</pre>

这是另外一个查询，它说明你能将**mysql**用作一个简单的计算器：

<pre>mysql&gt; **SELECT SIN(PI()/4), (4+1)*5;**</pre>
<pre>+------------------+---------+</pre>
<pre>| SIN(PI()/4)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | (4+1)*5 |</pre>
<pre>+------------------+---------+</pre>
<pre>| 0.70710678118655 |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 25 |</pre>
<pre>+------------------+---------+</pre>
<pre>1 row in set (0.02 sec)</pre>

至此显示的命令是相当短的单行语句。你可以在一行上输入多条语句，只需要以一个分号间隔开各语句：

<pre>mysql&gt; **SELECT VERSION(); SELECT NOW();**</pre>
<pre>+-----------------+</pre>
<pre>| VERSION()&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+-----------------+</pre>
<pre>| 5.1.2-alpha-log |</pre>
<pre>+-----------------+</pre>
<pre>1 row in set (0.00 sec)</pre>
<pre>&nbsp;</pre>
<pre>+---------------------+</pre>
<pre>| NOW()&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+---------------------+</pre>
<pre>| 2005-10-11 15:15:00 |</pre>
<pre>+---------------------+</pre>
<pre>1 row in set (0.00 sec)</pre>

不必全在一个行内给出一个命令，较长命令可以输入到多个行中。**mysql**通过寻找终止分号而不是输入行的结束来决定语句在哪儿结束。（换句话说，**mysql**接受自由格式的输入：它收集输入行但直到看见分号才执行。）

这里是一个简单的多行语句的例子：

<pre>mysql&gt; **SELECT**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **USER()**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **,**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **CURRENT_DATE;**</pre>
<pre>+---------------+--------------+</pre>
<pre>| USER()&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | CURRENT_DATE |</pre>
<pre>+---------------+--------------+</pre>
<pre>| jon@localhost | 2005-10-11&nbsp;&nbsp; |</pre>
<pre>+---------------+--------------+</pre>

在这个例子中，在输入多行查询的第一行后，要注意提示符如何从mysql&gt;变为-&gt;，这正是**mysql**如何指出它没见到完整的语句并且正在等待剩余的部分。提示符是你的朋友，因为它提供有价值的反馈，如果使用该反馈，将总是知道**mysql**正在等待什么。

如果你决定不想执行正在输入过程中的一个命令，输入/c取消它：

<pre>mysql&gt; **SELECT**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **USER()**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **/c**</pre>
<pre>mysql&gt;</pre>

这里也要注意提示符，在你输入/c以后，它切换回到mysql&gt;，提供反馈以表明**mysql**准备接受一个新命令。

下表显示出可以看见的各个提示符并简述它们所表示的**mysql**的状态：

<table id="table1" border="1" cellpadding="0">
<tbody>
<tr>
<td>

**提示符**

</td>
<td width="490">

**含义**

</td>
</tr>
<tr>
<td>

mysql&gt;

</td>
<td width="490">

准备好接受新命令。

</td>
</tr>
<tr>
<td>

-&gt;

</td>
<td width="490">

等待多行命令的下一行。

</td>
</tr>
<tr>
<td>

'&gt;

</td>
<td width="490">

等待下一行，等待以单引号(&ldquo;'&rdquo;)开始的字符串的结束。

</td>
</tr>
<tr>
<td>

"&gt;

</td>
<td width="490">

等待下一行，等待以双引号(&ldquo;"&rdquo;)开始的字符串的结束。

</td>
</tr>
<tr>
<td>

`&gt;

</td>
<td width="490">

等待下一行，等待以反斜点(&lsquo;`&rsquo;)开始的识别符的结束。

</td>
</tr>
<tr>
<td>

/*&gt;

</td>
<td width="490">

等待下一行，等待以/*开始的注释的结束。

</td>
</tr>
</tbody>
</table>

当你打算在一个单行上发出一个命令时，通常会&ldquo;偶然&rdquo;出现多行语句，但是没有终止分号。在这种情况中，**mysql**等待进一步输入：

<pre>mysql&gt; **SELECT USER()**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt;</pre>

如果出现这种情况(你认为输完了语句，但是只有一个-&gt;提示符响应)，很可能**mysql**正在等待分号。如果你没有注意到提示符的提示，在意识到你需要做什么之前，你可能会呆坐一会儿。输入一个分号完成语句，**mysql**将执行：

<pre>mysql&gt; **SELECT USER()**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **;**</pre>
<pre>+---------------+</pre>
<pre>| USER()&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+---------------+</pre>
<pre>| jon@localhost |</pre>
<pre>+---------------+</pre>

在字符串收集期间将出现&nbsp;'&gt;&nbsp;和&nbsp;"&gt;&nbsp;提示符（提示MySQL正等待字符串的结束）。在MySQL中，可以写由&lsquo;'&rsquo;或&lsquo;"&rsquo;字符括起来的字符串&nbsp;(例如，'hello'或"goodbye")，并且**mysql**允许输入跨越多行的字符串。当看到一个&nbsp;'&gt;&nbsp;或&nbsp;"&gt;&nbsp;提示符时，这意味着已经输入了包含以&lsquo;'&rsquo;或&lsquo;"&rsquo;括号字符开始的字符串的一行，但是还没有输入终止字符串的匹配引号。这显示你粗心地省掉了一个引号字符。例如：

<pre>mysql&gt; **SELECT * FROM my_table WHERE name = 'Smith AND age &lt; 30;**</pre>
<pre>&nbsp;&nbsp;&nbsp; '&gt;</pre>

如果你输入SELECT语句，然后按**Enter（****回车）**键并等待结果，什么都没有出现。不要惊讶，&ldquo;为什么该查询这么长呢？&rdquo;，注意"&gt;提示符提供的线索。它告诉你**mysql**期望见到一个未终止字符串的余下部分。（你看见语句中的错误吗？字符串"Smith丢掉了第二个引号。）

走到这一步，你该做什么？最简单的是取消命令。然而，在这种情况下，你不能只是输入/c，因为**mysql**作为它正在收集的字符串的一部分来解释它！相反，应输入关闭的引号字符(这样**mysql**知道你完成了字符串)，然后输入/c：

<pre>mysql&gt; **SELECT * FROM my_table WHERE name = 'Smith AND age &lt; 30;**</pre>
<pre>&nbsp;&nbsp;&nbsp; '&gt; **'/c**</pre>
<pre>mysql&gt;</pre>

提示符回到mysql&gt;，显示**mysql**准备好接受一个新命令了。

`&gt;&nbsp;提示符类似于&nbsp;'&gt;&nbsp;和"&gt;&nbsp;提示符，但表示你已经开始但没有结束以`&gt;&nbsp;开始的识别符。

知道'&gt;和"&gt;提示符的含义很重要，因为如果你错误地输入一个未终止的字符串，任何后面输入的行将要被**mysql**忽略--包括包含QUIT的行！这可能令人相当困惑，特别是如果取消当前命令前还不知道你需要提供终止引号。

</div>
<div class="section">
<div class="titlepage">

## <a name="database-use"></a>3.3.&nbsp;创建并使用数据库

</div>
<div class="toc"><dl><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.1\. 创建并选择数据库</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#creating-database)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.2\. 创建表</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#creating-tables)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.3\. 将数据装入表中</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#loading-tables)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.4\. 从表检索信息</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#retrieving-data)</span></dt></dl></div>
<a class="indexterm" name="id2733936"></a><a class="indexterm" name="id2733946"></a><a class="indexterm" name="id2733956"></a>

知道怎样输入命令，便可以访问数据库了。

假定在你的家(你的&ldquo;动物园&rdquo;)中有很多宠物，并且你想跟踪关于它们各种类型的信息。你可以通过创建表来保存你的数据并根据所需要的信息装载他们，然后你可以从表中检索数据来回答关于动物不同种类的问题。本节显示如何做到所有这些事情：

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;创建数据库

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;创建数据库表

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;装载数据到数据库表

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;以各种方法从表中检索数据

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;使用多个表

动物园数据库很简单(特意的)，但是不难把它想象成可能用到类似数据库的真实世界情况。例如，农夫可以使用这样的一个数据库来追踪家畜，或者兽医可以用它跟踪病畜记录。从MySQL网址上可以获得后面章节中将用到的含有部分查询和样例数据的动物园分发。有**tar压缩格式**&nbsp;([<span style="text-decoration: underline;"><span style="color: #0000ff;">http://downloads.mysql.com/docs/menagerie-db.tar.gz</span></span>](http://downloads.mysql.com/docs/menagerie-db.tar.gz))和Zip压缩格式&nbsp;([<span style="text-decoration: underline;"><span style="color: #0000ff;">http://downloads.mysql.com/docs/menagerie-db.zip</span></span>](http://downloads.mysql.com/docs/menagerie-db.zip))。

使用SHOW语句找出服务器上当前存在什么数据库：

<pre>mysql&gt; **SHOW DATABASES;**</pre>
<pre>+----------+</pre>
<pre>| Database |</pre>
<pre>+----------+</pre>
<pre>| mysql&nbsp;&nbsp;&nbsp; |</pre>
<pre>| test&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| tmp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+----------+</pre>

可能你的机器上的数据库列表是不同的，但是很可能有mysql和test数据库。mysql是必需的，因为它描述用户访问权限，test数据库经常作为用户试身手的工作区。

请注意如果没有SHOW DATABASES权限，则不能看见所有数据库。参见[<span style="text-decoration: underline;"><span style="color: #0000ff;">13.5.1.3节，&ldquo;GRANT和REVOKE语法&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/sql-syntax.html#grant "13.5.1.3.&nbsp;GRANT and REVOKE Syntax")。

如果test数据库存在，尝试访问它：

<pre>mysql&gt; **USE test**</pre>
<pre>Database changed</pre>

注意，USE，类似QUIT，不需要一个分号。（如果你喜欢，你可以用一个分号终止这样的语句；这无碍）USE语句在使用上也有另外一个特殊的地方：它必须在一个单行上给出。

你可列在后面的例子中使用test数据库(如果你能访问它)，但是你在该数据库创建的任何东西可以被访问它的其它人删除，因此，你应该询问MySQL管理员许可你使用自己的一个数据库。假定你想要调用你的menagerie，管理员需要执行这样一条命令：

<pre>mysql&gt; **GRANT ALL ON menagerie.* TO 'your_mysql_name'@'your_client_host';**</pre>

这里your_mysql_name是分配给你的**MySQL**用户名，your_client_host是所连接的服务器所在的主机。

<div class="section">
<div class="titlepage">

### <a name="creating-database"></a>3.3.1.&nbsp;创建并选择数据库

</div>
<a class="indexterm" name="id2734185"></a><a class="indexterm" name="id2734195"></a></div>
<div class="section">
<div class="titlepage">如果管理员在设置权限时为你创建了数据库，你可以开始使用它。否则，你需要自己创建数据库：
<pre>mysql&gt; **CREATE DATABASE menagerie;**</pre>

在Unix下，数据库名称是区分大小写的(不像SQL关键字)，因此你必须总是以menagerie访问数据库，而不能用Menagerie、MENAGERIE或其它一些变量。对表名也是这样的。（在Windows下，该限制不适用，尽管你必须在一个给定的查询中使用同样的大小写来引用数据库和表。但是，由于多种原因，作为最好的惯例，一定要使用与数据库创建时的同样的大小写。）

创建数据库并不表示选定并使用它，你必须明确地操作。为了使menagerie成为当前的数据库，使用这个命令：

<pre>mysql&gt; **USE menagerie**</pre>
<pre>Database changed</pre>

数据库只需要创建一次，但是必须在每次启动**mysql**会话时在使用前先选择它。你可以根据上面的例子执行一个USE语句来实现。还可以在调用**mysql**时，通过命令行选择数据库，只需要在提供连接参数之后指定数据库名称。例如：

<pre>shell&gt; **mysql -h _host_ -u _user_ -p menagerie**</pre>
<pre>Enter password: ************</pre>

注意，刚才显示的命令行中的menagerie**不**是你的 密码。如果你想要在命令行上在-p选项后提供 密码，则不能插入空格(例如，如-pmypassword，不是-p mypassword)。但是，不建议在命令行输入密码，因为这样会暴露 密码，能被在机器上登录的其它用户窥探到。

### <a name="creating-tables"></a>3.3.2.&nbsp;创建表

</div>
<a class="indexterm" name="id2734341"></a><a class="indexterm" name="id2734351"></a>

创建数据库是很容易的部分，但是在这时它是空的，正如SHOW TABLES将告诉你的：

<pre>mysql&gt; **SHOW TABLES;**</pre>
<pre>Empty set (0.00 sec)</pre>

较难的部分是决定你的数据库结构应该是什么：你需要什么数据库表，各数据库表中有什么样的列。

你将需要一个包含你每个宠物的记录的表。它可称为pet表，并且它应该包含，最少，每个动物的名字。因为名字本身不是很有趣，表应该包含另外的信息。例如，如果在你豢养宠物的家庭有超过一个人，你可能想要列出每个动物的主人。你可能也想要记录例如种类和性别的一些基本的描述信息。

年龄呢？那可能有趣，但是存储到一个数据库中不是一件好事情。年龄随着时间流逝而变化，这意味着你将要不断地更新你的记录。相反,&nbsp;存储一个固定值例如生日比较好，那么，无论何时你需要年龄，可以以当前日期和出生日期之间的差来计算它。**MySQL**提供了日期运算函数，因此这并不困难。存储出生日期而非年龄还有其它优点：

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;你可以使用数据库完成这样的任务，例如生成即将到来的宠物生日的提示。（如果你认为这类查询有点蠢，注意，这与从商务数据库来识别出不久要发给生日祝贺的客户是同一个问题，因为计算机帮助私人联络。）

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;你可以相对于日期而不止是当前日期来计算年龄。例如，如果你在数据库存储死亡日期，你能很容易地计算出一只宠物死时有多大。

你可能想到pet表中其它有用的其它类型信息，但是到目前为止这些已经足够了：名字、主人、种类，性别、出生和死亡日期。

使用一个CREATE TABLE语句指定你的数据库表的布局：

<pre>mysql&gt; **CREATE TABLE pet (name VARCHAR(20), owner VARCHAR(20),**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **species VARCHAR(20), sex CHAR(1), birth DATE, death DATE);**</pre>

VARCHAR适合于name、owner和species列，因为列值是变长的。这些列的长度不必都相同，而且不必是20。你可以挑选从1到65535的任何长度，从中选择一个最合理的值。（如果选择得不合适，后来证明你需要一个更长的字段，**MySQL**提供一个ALTER TABLE语句。）

可以用多种类型的值来表示动物记录中的性别，例如，"m"和"f"，或"male"和"female"。使用单字符"m"和"f"是最简单的方法。

很显然，birth和death列应选用DATE数据类。

创建了数据库表后，SHOW TABLES应该产生一些输出：

<pre>mysql&gt; **SHOW TABLES;**</pre>
<pre>+---------------------+</pre>
<pre>| Tables in menagerie |</pre>
<pre>+---------------------+</pre>
<pre>| pet&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+---------------------+</pre>

为了验证你的表是按你期望的方式创建，使用一个DESCRIBE语句：

<pre>mysql&gt; **DESCRIBE pet;**</pre>
<pre>+---------+-------------+------+-----+---------+-------+</pre>
<pre>| Field&nbsp;&nbsp; | Type&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | Null | Key | Default | Extra |</pre>
<pre>+---------+-------------+------+-----+---------+-------+</pre>
<pre>| name&nbsp;&nbsp;&nbsp; | varchar(20) | YES&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; | NULL&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| owner&nbsp;&nbsp; | varchar(20) | YES&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; | NULL&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| species | varchar(20) | YES&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; | NULL&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| sex&nbsp;&nbsp;&nbsp;&nbsp; | char(1)&nbsp;&nbsp;&nbsp;&nbsp; | YES&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; | NULL&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| birth&nbsp;&nbsp; | date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | YES&nbsp; |&nbsp; &nbsp;&nbsp;&nbsp;| NULL&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| death&nbsp;&nbsp; | date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | YES&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; | NULL&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+---------+-------------+------+-----+---------+-------+</pre>

你可以随时使用DESCRIBE，例如，如果你忘记表中的列的名称或类型时。

</div>
<div class="section">
<div class="titlepage">

### <a name="loading-tables"></a>3.3.3.&nbsp;将数据装入表中

</div>
<a class="indexterm" name="id2734617"></a><a class="indexterm" name="id2734627"></a><a class="indexterm" name="id2734637"></a>

创建表后，需要填入内容。通过LOAD DATA和INSERT语句可以完成该任务。

假定你的宠物纪录描述如下。（假定在**MySQL**中期望的日期格式是YYYY-MM-DD；这可能与你习惯的不同。）

<table id="table2" border="1" cellpadding="0">
<tbody>
<tr>
<td>

**name**

</td>
<td>

**owner**

</td>
<td>

**species**

</td>
<td>

**sex**

</td>
<td>

**birth**

</td>
<td>

**death**

</td>
</tr>
<tr>
<td>

Fluffy

</td>
<td>

Harold

</td>
<td>

cat

</td>
<td>

f

</td>
<td>

1993-02-04

</td>
<td>

&nbsp;

</td>
</tr>
<tr>
<td>

Claws

</td>
<td>

Gwen

</td>
<td>

cat

</td>
<td>

m

</td>
<td>

1994-03-17

</td>
<td>

&nbsp;

</td>
</tr>
<tr>
<td>

Buffy

</td>
<td>

Harold

</td>
<td>

dog

</td>
<td>

f

</td>
<td>

1989-05-13

</td>
<td>

&nbsp;

</td>
</tr>
<tr>
<td>

Fang

</td>
<td>

Benny

</td>
<td>

dog

</td>
<td>

m

</td>
<td>

1990-08-27

</td>
<td>

&nbsp;

</td>
</tr>
<tr>
<td>

Bowser

</td>
<td>

Diane

</td>
<td>

dog

</td>
<td>

m

</td>
<td>

1979-08-31

</td>
<td>

1995-07-29

</td>
</tr>
<tr>
<td>

Chirpy

</td>
<td>

Gwen

</td>
<td>

bird

</td>
<td>

f

</td>
<td>

1998-09-11

</td>
<td>

&nbsp;

</td>
</tr>
<tr>
<td>

Whistler

</td>
<td>

Gwen

</td>
<td>

bird

</td>
<td>

&nbsp;

</td>
<td>

1997-12-09

</td>
<td>

&nbsp;

</td>
</tr>
<tr>
<td>

Slim

</td>
<td>

Benny

</td>
<td>

snake

</td>
<td>

m

</td>
<td>

1996-04-29

</td>
<td>

&nbsp;

</td>
</tr>
</tbody>
</table>

因为你是从一个空表开始的，填充它的一个简易方法是创建一个文本文件，每个动物各一行，然后用一个语句将文件的内容装载到表中。

你可以创建一个文本文件<tt>&ldquo;pet.txt&rdquo;</tt>，每行包含一个记录，用定位符(tab)把值分开，并且以CREATE TABLE语句中列出的列次序给出。对于丢失的值(例如未知的性别，或仍然活着的动物的死亡日期)，你可以使用NULL值。为了在你的文本文件中表示这些内容，使用/N（反斜线，字母N）。例如，Whistler鸟的记录应为(这里值之间的空白是一个定位符)：

<table id="table3" border="1" cellpadding="0">
<tbody>
<tr>
<td>

**name**

</td>
<td>

**owner**

</td>
<td>

**species**

</td>
<td>

**sex**

</td>
<td>

**birth**

</td>
<td>

**death**

</td>
</tr>
<tr>
<td>

Whistler

</td>
<td>

Gwen

</td>
<td>

bird

</td>
<td>

/N

</td>
<td>

1997-12-09

</td>
<td>

/N

</td>
</tr>
</tbody>
</table>

要想将文本文件<tt>&ldquo;pet.txt&rdquo;</tt>装载到pet表中，使用这个命令：

<pre>mysql&gt; **LOAD DATA LOCAL INFILE '/path/pet.txt' INTO TABLE pet;**</pre>

请注意如果用Windows中的编辑器（使用/r/n做为行的结束符）创建文件，应使用：

<pre>mysql&gt; **LOAD DATA LOCAL INFILE '/path/pet.txt' INTO TABLE pet**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **LINES TERMINATED BY '/r/n';**</pre>

（在运行OS X的Apple机上，应使用行结束符'/r'。）

如果你愿意，你能明确地在LOAD DATA语句中指出列值的分隔符和行尾标记，但是默认标记是定位符和换行符。这对读入文件<tt>&ldquo;pet.txt&rdquo;</tt>的语句已经足够。

如果该语句失败，可能是你安装的MySQL不与使用默认值的本地文件兼容。关于如何更改请参见[<span style="text-decoration: underline;"><span style="color: #0000ff;">5.6.4节，&ldquo;LOAD DATA LOCAL安全问题&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/database-administration.html#load-data-local "5.6.4.&nbsp;Security Issues with LOAD DATA LOCAL")。

如果想要一次增加一个新记录，可以使用INSERT语句。最简单的形式是，提供每一列的值，其顺序与CREATE TABLE语句中列的顺序相同。假定Diane把一只新仓鼠命名为Puffball，你可以使用下面的INSERT语句添加一条新记录：

<pre>mysql&gt; **INSERT INTO pet**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **VALUES ('Puffball','Diane','hamster','f','1999-03-30',NULL);**</pre>

注意，这里字符串和日期值均为引号扩起来的字符串。另外，可以直接用INSERT语句插入NULL代表不存在的值。不能使用LOAD DATA中所示的的/N。

从这个例子，你应该能看到涉及很多的键入用多个INSERT语句而非单个LOAD DATA语句装载你的初始记录。

</div>
<div class="section">
<div class="titlepage">

### <a name="retrieving-data"></a>3.3.4.&nbsp;从表检索信息

</div>
<div class="toc"><dl><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.4.1\. 选择所有数据</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#selecting-all)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.4.2\. 选择特殊行</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#selecting-rows)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.4.3\. 选择特殊列</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#selecting-columns)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.4.4\. 分类行</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#sorting-rows)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.4.5\. 日期计算</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#date-calculations)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.4.6\. NULL值操作</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#working-with-null)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.4.7\. 模式匹配</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#pattern-matching)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.4.8\. 计数行</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#counting-rows)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.4.9\. 使用1个以上的表
&nbsp;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#multiple-tables)</span></dt></dl></div>

<a class="indexterm" name="id2735238"></a><a class="indexterm" name="id2735248"></a><a class="indexterm" name="id2735258"></a><a class="indexterm" name="id2735268"></a>
<div class="section">
<div class="titlepage">SELECT语句用来从数据表中检索信息。语句的一般格式是：
<pre>SELECT _what_to_select_</pre>
<pre>FROM _which_table_</pre>
<pre>WHERE _conditions_to_satisfy_;</pre>

what_to_select指出你想要看到的内容，可以是列的一个表，或*表示&ldquo;所有的列&rdquo;。which_table指出你想要从其检索数据的表。WHERE子句是可选项，如果选择该项，conditions_to_satisfy指定行必须满足的检索条件。

#### <a name="selecting-all"></a>3.3.4.1.&nbsp;选择所有数据

</div>
</div>
<div class="section">
<div class="titlepage">SELECT最简单的形式是从一个表中检索所有记录：
<pre>mysql&gt; **SELECT * FROM pet;**</pre>
<pre>+----------+--------+---------+------+------------+------------+</pre>
<pre>| name&nbsp;&nbsp;&nbsp;&nbsp; | owner&nbsp; | species | sex&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+----------+--------+---------+------+------------+------------+</pre>
<pre>| Fluffy&nbsp;&nbsp; | Harold | cat&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1993-02-04 | NULL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| Claws&nbsp;&nbsp;&nbsp; | Gwen&nbsp;&nbsp; | cat&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1994-03-17 | NULL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| Buffy&nbsp;&nbsp;&nbsp; | Harold | dog&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1989-05-13 | NULL&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;|</pre>
<pre>| Fang&nbsp;&nbsp;&nbsp;&nbsp; | Benny&nbsp; | dog&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1990-08-27 | NULL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| Bowser&nbsp;&nbsp; | Diane&nbsp; | dog&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1979-08-31 | 1995-07-29 |</pre>
<pre>| Chirpy&nbsp;&nbsp; | Gwen&nbsp;&nbsp; | bird&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1998-09-11 | NULL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| Whistler | Gwen&nbsp;&nbsp; | bird&nbsp;&nbsp;&nbsp; | NULL | 1997-12-09 | NULL &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|</pre>
<pre>| Slim&nbsp;&nbsp;&nbsp;&nbsp; | Benny&nbsp; | snake&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1996-04-29 | NULL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| Puffball | Diane&nbsp; | hamster | f&nbsp;&nbsp;&nbsp; | 1999-03-30 | NULL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+----------+--------+---------+------+------------+------------+</pre>

如果你想要浏览整个表，可以使用这种形式的SELECT，例如，刚刚装载了初始数据集以后。也有可能你想到Bowser的生日看起来不很对。查阅你原来的家谱，你发现正确的出生年是1989，而不是1979。

至少有两种修正方法：

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;编辑文件<tt>&ldquo;pet.txt&rdquo;</tt>改正错误，然后使用DELETE和LOAD DATA清空并重新装载表:

<pre>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; mysql&gt; **DELETE FROM pet;**</pre>
<pre>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; mysql&gt; **LOAD DATA LOCAL INFILE 'pet.txt' INTO TABLE pet;**</pre>

然而,&nbsp;如果这样操做，必须重新输入Puffball记录。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;用一个UPDATE语句仅修正错误记录：

<pre>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; mysql&gt; **UPDATE pet SET birth = '1989-08-31' WHERE name = 'Bowser';**</pre>

UPDATE只更改有问题的记录，不需要重新装载数据库表。

#### <a name="selecting-rows"></a>3.3.4.2.&nbsp;选择特殊行

</div>
<a class="indexterm" name="id2735486"></a><a class="indexterm" name="id2735496"></a></div>
<div class="section">
<div class="titlepage">如上所示，检索整个表是容易的。只需要从SELECT语句中删掉WHERE子句。但是一般你不想看到整个表，特别地当表变得很大时。相反，你通常对回答一个具体的问题更感兴趣，在这种情况下在你想要的信息上进行一些限制。让我们看一些他们回答的有关你宠物的问题的选择查询。

可以从表中只选择特定的行。例如，如果你想要验证你对Bowser的生日所做的更改，按下述方法选择Bowser的记录：

<pre>mysql&gt; **SELECT * FROM pet WHERE name = 'Bowser';**</pre>
<pre>+--------+-------+---------+------+------------+------------+</pre>
<pre>| name&nbsp;&nbsp; | owner | species | sex&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+--------+-------+---------+------+------------+------------+</pre>
<pre>| Bowser | Diane | dog&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1989-08-31 | 1995-07-29 |</pre>
<pre>+--------+-------+---------+------+------------+------------+</pre>

输出证实正确的年份记录为1989，而不是1979。

字符串比较时通常对大小些不敏感，因此你可以将名字指定为"bowser"、"BOWSER"等，查询结果相同。

你可以在任何列上指定条件，不只仅仅是name。例如，如果你想要知道哪个动物在1998以后出生的，测试birth列：

<pre>mysql&gt; **SELECT * FROM pet WHERE birth &gt; '1998-1-1';**</pre>
<pre>+----------+-------+---------+------+------------+-------+</pre>
<pre>| name&nbsp;&nbsp;&nbsp;&nbsp; | owner | species | sex&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death |</pre>
<pre>+----------+-------+---------+------+------------+-------+</pre>
<pre>| Chirpy&nbsp; &nbsp;| Gwen&nbsp; | bird&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1998-09-11 | NULL&nbsp; |</pre>
<pre>| Puffball | Diane | hamster | f&nbsp;&nbsp;&nbsp; | 1999-03-30 | NULL&nbsp; |</pre>
<pre>+----------+-------+---------+------+------------+-------+</pre>

可以组合条件，例如，找出雌性的狗：

<pre>mysql&gt; **SELECT * FROM pet WHERE species = 'dog' AND sex = 'f';**</pre>
<pre>+-------+--------+---------+------+------------+-------+</pre>
<pre>| name&nbsp; | owner&nbsp; | species | sex&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death |</pre>
<pre>+-------+--------+---------+------+------------+-------+</pre>
<pre>| Buffy | Harold | dog&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1989-05-13 | NULL&nbsp; |</pre>
<pre>+-------+--------+---------+------+------------+-------+</pre>

上面的查询使用AND逻辑操作符，也有一个OR操作符：

<pre>mysql&gt; **SELECT * FROM pet WHERE species = 'snake' OR species = 'bird';**</pre>
<pre>+----------+-------+---------+------+------------+-------+</pre>
<pre>| name&nbsp;&nbsp;&nbsp;&nbsp; | owner | species | sex&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death |</pre>
<pre>+----------+-------+---------+------+------------+-------+</pre>
<pre>| Chirpy&nbsp;&nbsp; | Gwen&nbsp; | bird&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1998-09-11 | NULL&nbsp; |</pre>
<pre>| Whistler | Gwen&nbsp; | bird&nbsp;&nbsp;&nbsp; | NULL | 1997-12-09 | NULL&nbsp; |</pre>
<pre>| Slim&nbsp;&nbsp;&nbsp;&nbsp; | Benny | snake&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1996-04-29 | NULL&nbsp; |</pre>
<pre>+----------+-------+---------+------+------------+-------+</pre>

AND和OR可以混用，但AND比OR具有更高的优先级。如果你使用两个操作符，使用圆括号指明如何对条件进行分组是一个好主意：

<pre>mysql&gt; **SELECT * FROM pet WHERE (species = 'cat' AND sex = 'm')**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **OR (species = 'dog' AND sex = 'f');**</pre>
<pre>+-------+--------+---------+------+------------+-------+</pre>
<pre>| name&nbsp; | owner&nbsp; | species | sex&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death |</pre>
<pre>+-------+--------+---------+------+------------+-------+</pre>
<pre>| Claws | Gwen&nbsp;&nbsp; | cat&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1994-03-17 | NULL&nbsp; |</pre>
<pre>| Buffy | Harold | dog&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1989-05-13 | NULL&nbsp; |</pre>
<pre>+-------+--------+---------+------+------------+-------+</pre>

#### <a name="selecting-columns"></a>3.3.4.3.&nbsp;选择特殊列

</div>
<a class="indexterm" name="id2735687"></a><a class="indexterm" name="id2735697"></a></div>
<div class="section">
<div class="titlepage">如果你不想看到表中的所有行，就命名你感兴趣的列，用逗号分开。例如，如果你想要知道你的动物什么时候出生的，选择name和birth列：
<pre>mysql&gt; **SELECT name, birth FROM pet;**</pre>
<pre>+----------+------------+</pre>
<pre>| name&nbsp;&nbsp;&nbsp;&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+----------+------------+</pre>
<pre>| Fluffy&nbsp;&nbsp; | 1993-02-04 |</pre>
<pre>| Claws&nbsp;&nbsp;&nbsp; | 1994-03-17 |</pre>
<pre>| Buffy&nbsp;&nbsp;&nbsp; | 1989-05-13 |</pre>
<pre>| Fang&nbsp;&nbsp;&nbsp;&nbsp; | 1990-08-27 |</pre>
<pre>| Bowser&nbsp;&nbsp; | 1989-08-31 |</pre>
<pre>| Chirpy&nbsp;&nbsp; | 1998-09-11 |</pre>
<pre>| Whistler | 1997-12-09 |</pre>
<pre>| Slim&nbsp;&nbsp;&nbsp;&nbsp; | 1996-04-29 |</pre>
<pre>| Puffball | 1999-03-30 |</pre>
<pre>+----------+------------+</pre>

找出谁拥有宠物，使用这个查询：

<pre>mysql&gt; **SELECT owner FROM pet;**</pre>
<pre>+--------+</pre>
<pre>| owner&nbsp; |</pre>
<pre>+--------+</pre>
<pre>| Harold |</pre>
<pre>| Gwen&nbsp;&nbsp; |</pre>
<pre>| Harold |</pre>
<pre>| Benny&nbsp; |</pre>
<pre>| Diane&nbsp; |</pre>
<pre>| Gwen&nbsp;&nbsp; |</pre>
<pre>| Gwen&nbsp;&nbsp; |</pre>
<pre>| Benny&nbsp; |</pre>
<pre>| Diane&nbsp; |</pre>
<pre>+--------+</pre>

请注意该查询只是简单地检索每个记录的owner列，并且他们中的一些出现多次。为了使输出减到最少，增加关键字DISTINCT检索出每个唯一的输出记录：

<pre>mysql&gt; **SELECT DISTINCT owner FROM pet;**</pre>
<pre>+--------+</pre>
<pre>| owner&nbsp; |</pre>
<pre>+--------+</pre>
<pre>| Benny&nbsp; |</pre>
<pre>| Diane&nbsp; |</pre>
<pre>| Gwen&nbsp;&nbsp; |</pre>
<pre>| Harold |</pre>
<pre>+--------+</pre>

可以使用一个WHERE子句结合行选择与列选择。例如，要想查询狗和猫的出生日期，使用这个查询：

<pre>mysql&gt; **SELECT name, species, birth FROM pet**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **WHERE species = 'dog' OR species = 'cat';**</pre>
<pre>+--------+---------+------------+</pre>
<pre>| name&nbsp;&nbsp; | species | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+--------+---------+------------+</pre>
<pre>| Fluffy | cat&nbsp;&nbsp;&nbsp;&nbsp; | 1993-02-04 |</pre>
<pre>| Claws&nbsp; | cat&nbsp;&nbsp;&nbsp;&nbsp; | 1994-03-17 |</pre>
<pre>| Buffy&nbsp; | dog&nbsp;&nbsp;&nbsp;&nbsp; | 1989-05-13 |</pre>
<pre>| Fang&nbsp;&nbsp; | dog&nbsp;&nbsp;&nbsp;&nbsp; | 1990-08-27 |</pre>
<pre>| Bowser | dog&nbsp;&nbsp;&nbsp;&nbsp; | 1989-08-31 |</pre>
<pre>+--------+---------+------------+</pre>

#### <a name="sorting-rows"></a>3.3.4.4.&nbsp;分类行

</div>
<a class="indexterm" name="id2735822"></a><a class="indexterm" name="id2735830"></a><a class="indexterm" name="id2735841"></a><a class="indexterm" name="id2735851"></a><a class="indexterm" name="id2735861"></a></div>
<div class="section">
<div class="titlepage">你可能已经注意到前面的例子中结果行没有以特定的顺序显示。然而，当行按某种方式排序时，检查查询输出通常更容易。为了排序结果，使用ORDER BY子句。

这里是动物生日，按日期排序：

<pre>mysql&gt; **SELECT name, birth FROM pet ORDER BY birth;**</pre>
<pre>+----------+------------+</pre>
<pre>| name&nbsp;&nbsp;&nbsp;&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+----------+------------+</pre>
<pre>| Buffy&nbsp;&nbsp;&nbsp; | 1989-05-13 |</pre>
<pre>| Bowser&nbsp;&nbsp; | 1989-08-31 |</pre>
<pre>| Fang&nbsp;&nbsp;&nbsp;&nbsp; | 1990-08-27 |</pre>
<pre>| Fluffy&nbsp;&nbsp; | 1993-02-04 |</pre>
<pre>| Claws&nbsp;&nbsp;&nbsp; | 1994-03-17 |</pre>
<pre>| Slim&nbsp;&nbsp;&nbsp;&nbsp; | 1996-04-29 |</pre>
<pre>| Whistler | 1997-12-09 |</pre>
<pre>| Chirpy&nbsp;&nbsp; | 1998-09-11 |</pre>
<pre>| Puffball | 1999-03-30 |</pre>
<pre>+----------+------------+</pre>

在字符类型列上，与所有其他比较操作类似，分类功能正常情况下是以区分大小写的方式执行的。这意味着，对于等同但大小写不同的列，并未定义其顺序。对于某一列，可以使用BINARY强制执行区分大小写的分类功能，如：ORDER BY BINARY&nbsp;_col_name_.

默认排序是升序，最小的值在第一。要想以降序排序，在你正在排序的列名上增加DESC（降序 ）关键字：

<pre>mysql&gt; **SELECT name, birth FROM pet ORDER BY birth DESC;**</pre>
<pre>+----------+------------+</pre>
<pre>| name&nbsp;&nbsp;&nbsp;&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+----------+------------+</pre>
<pre>| Puffball | 1999-03-30 |</pre>
<pre>| Chirpy&nbsp;&nbsp; | 1998-09-11 |</pre>
<pre>| Whistler | 1997-12-09 |</pre>
<pre>| Slim&nbsp;&nbsp;&nbsp;&nbsp; | 1996-04-29 |</pre>
<pre>| Claws&nbsp;&nbsp;&nbsp; | 1994-03-17 |</pre>
<pre>| Fluffy&nbsp;&nbsp; | 1993-02-04 |</pre>
<pre>| Fang&nbsp;&nbsp;&nbsp;&nbsp; | 1990-08-27 |</pre>
<pre>| Bowser&nbsp;&nbsp; | 1989-08-31 |</pre>
<pre>| Buffy&nbsp;&nbsp;&nbsp; | 1989-05-13 |</pre>
<pre>+----------+------------+</pre>

可以对多个列进行排序，并且可以按不同的方向对不同的列进行排序。例如，按升序对动物的种类进行排序，然后按降序根据生日对各动物种类进行排序（最年轻的动物在最前面），使用下列查询：

<pre>mysql&gt; **SELECT name, species, birth FROM pet**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **ORDER BY species, birth DESC;**</pre>
<pre>+----------+---------+------------+</pre>
<pre>| name&nbsp;&nbsp;&nbsp;&nbsp; | species | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+----------+---------+------------+</pre>
<pre>| Chirpy&nbsp;&nbsp; | bird&nbsp;&nbsp;&nbsp; | 1998-09-11 |</pre>
<pre>| Whistler | bird&nbsp;&nbsp;&nbsp; | 1997-12-09 |</pre>
<pre>| Claws&nbsp;&nbsp;&nbsp; | cat&nbsp;&nbsp;&nbsp;&nbsp; | 1994-03-17 |</pre>
<pre>| Fluffy&nbsp;&nbsp; | cat&nbsp;&nbsp;&nbsp;&nbsp; | 1993-02-04 |</pre>
<pre>| Fang&nbsp;&nbsp;&nbsp;&nbsp; | dog&nbsp;&nbsp;&nbsp;&nbsp; | 1990-08-27 |</pre>
<pre>| Bowser&nbsp;&nbsp; | dog&nbsp;&nbsp;&nbsp;&nbsp; | 1989-08-31 |</pre>
<pre>| Buffy&nbsp;&nbsp;&nbsp; | dog&nbsp;&nbsp;&nbsp;&nbsp; | 1989-05-13 |</pre>
<pre>| Puffball | hamster | 1999-03-30 |</pre>
<pre>| Slim&nbsp;&nbsp;&nbsp;&nbsp; | snake&nbsp;&nbsp; | 1996-04-29 |</pre>
<pre>+----------+---------+------------+</pre>

注意DESC关键字仅适用于在它前面的列名(birth)；不影响species列的排序顺序。

#### <a name="date-calculations"></a>3.3.4.5.&nbsp;日期计算

</div>
<a class="indexterm" name="id2736007"></a><a class="indexterm" name="id2736014"></a><a class="indexterm" name="id2736024"></a><a class="indexterm" name="id2736034"></a>

**MySQL**提供了几个函数，可以用来计算日期，例如，计算年龄或提取日期部分。

要想确定每个宠物有多大，可以计算当前日期的年和出生日期之间的差。如果当前日期的日历年比出生日期早，则减去一年。以下查询显示了每个宠物的出生日期、当前日期和年龄数值的年数字。

<pre>mysql&gt; **SELECT name, birth, CURDATE(),**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **(YEAR(CURDATE())-YEAR(birth))**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **- (RIGHT(CURDATE(),5)&lt;RIGHT(birth,5))**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **AS age**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **FROM pet;**</pre>
<pre>+----------+------------+------------+------+</pre>
<pre>| name&nbsp;&nbsp;&nbsp;&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | CURDATE()&nbsp; | age&nbsp; |</pre>
<pre>+----------+------------+------------+------+</pre>
<pre>| Fluffy&nbsp;&nbsp; | 1993-02-04 | 2003-08-19 |&nbsp;&nbsp; 10 |</pre>
<pre>| Claws&nbsp;&nbsp;&nbsp; | 1994-03-17 | 2003-08-19 |&nbsp;&nbsp;&nbsp; 9 |</pre>
<pre>| Buffy&nbsp;&nbsp;&nbsp; | 1989-05-13 | 2003-08-19 |&nbsp;&nbsp; 14 |</pre>
<pre>| Fang&nbsp;&nbsp;&nbsp;&nbsp; | 1990-08-27 | 2003-08-19 |&nbsp;&nbsp; 12 |</pre>
<pre>| Bowser&nbsp;&nbsp; | 1989-08-31 | 2003-08-19 |&nbsp;&nbsp; 13 |</pre>
<pre>| Chirpy&nbsp;&nbsp; | 1998-09-11 | 2003-08-19 |&nbsp;&nbsp;&nbsp; 4 |</pre>
<pre>| Whistler | 1997-12-09 | 2003-08-19 |&nbsp;&nbsp;&nbsp; 5 |</pre>
<pre>| Slim&nbsp;&nbsp;&nbsp;&nbsp; | 1996-04-29 | 2003-08-19 |&nbsp;&nbsp;&nbsp; 7 |</pre>
<pre>| Puffball | 1999-03-30 | 2003-08-19 |&nbsp;&nbsp;&nbsp; 4 |</pre>
<pre>+----------+------------+------------+------+</pre>

此处，YEAR()提取日期的年部分，RIGHT()提取日期的MM-DD&nbsp;(日历年)部分的最右面5个字符。比较MM-DD值的表达式部分的值一般为1或0，如果CURDATE()的年比birth的年早，则年份应减去1。整个表达式有些难懂，使用_alias_&nbsp;(age)来使输出的列标记更有意义。

尽管查询可行，如果以某个顺序排列行，则能更容易地浏览结果。添加ORDER BY name子句按照名字对输出进行排序则能够实现。

<pre>mysql&gt; **SELECT name, birth, CURDATE(),**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **(YEAR(CURDATE())-YEAR(birth))**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **- (RIGHT(CURDATE(),5)&lt;RIGHT(birth,5))**</pre>
<pre> &nbsp;&nbsp;&nbsp;-&gt; **AS age**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **FROM pet ORDER BY name;**</pre>
<pre>+----------+------------+------------+------+</pre>
<pre>| name&nbsp;&nbsp;&nbsp;&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | CURDATE()&nbsp; | age&nbsp; |</pre>
<pre>+----------+------------+------------+------+</pre>
<pre>| Bowser&nbsp;&nbsp; | 1989-08-31 | 2003-08-19 |&nbsp;&nbsp; 13 |</pre>
<pre>| Buffy&nbsp;&nbsp;&nbsp; | 1989-05-13 | 2003-08-19 |&nbsp;&nbsp; 14 |</pre>
<pre>| Chirpy&nbsp;&nbsp; | 1998-09-11 | 2003-08-19 |&nbsp;&nbsp;&nbsp; 4 |</pre>
<pre>| Claws&nbsp;&nbsp;&nbsp; | 1994-03-17 | 2003-08-19 |&nbsp;&nbsp;&nbsp; 9 |</pre>
<pre>| Fang&nbsp;&nbsp;&nbsp;&nbsp; | 1990-08-27 | 2003-08-19 |&nbsp;&nbsp; 12 |</pre>
<pre>| Fluffy&nbsp;&nbsp; | 1993-02-04 | 2003-08-19 |&nbsp;&nbsp; 10 |</pre>
<pre>| Puffball | 1999-03-30 | 2003-08-19 |&nbsp;&nbsp;&nbsp; 4 |</pre>
<pre>| Slim&nbsp; &nbsp;&nbsp;&nbsp;| 1996-04-29 | 2003-08-19 |&nbsp;&nbsp;&nbsp; 7 |</pre>
<pre>| Whistler | 1997-12-09 | 2003-08-19 |&nbsp;&nbsp;&nbsp; 5 |</pre>
<pre>+----------+------------+------------+------+</pre>

为了按age而非name排序输出，只要再使用一个ORDER BY子句：

<pre>mysql&gt; **SELECT name, birth, CURDATE(),**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **(YEAR(CURDATE())-YEAR(birth))**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **- (RIGHT(CURDATE(),5)&lt;RIGHT(birth,5))**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **AS age**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **FROM pet ORDER BY age;**</pre>
<pre>+----------+------------+------------+------+</pre>
<pre>| name&nbsp;&nbsp;&nbsp;&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | CURDATE()&nbsp; | age&nbsp; |</pre>
<pre>+----------+------------+------------+------+</pre>
<pre>| Chirpy&nbsp;&nbsp; | 1998-09-11 | 2003-08-19 |&nbsp;&nbsp;&nbsp; 4 |</pre>
<pre>| Puffball | 1999-03-30 | 2003-08-19 |&nbsp;&nbsp;&nbsp; 4 |</pre>
<pre>| Whistler | 1997-12-09 | 2003-08-19 |&nbsp;&nbsp;&nbsp; 5 |</pre>
<pre>| Slim&nbsp;&nbsp;&nbsp;&nbsp; | 1996-04-29 | 2003-08-19 |&nbsp;&nbsp;&nbsp; 7 |</pre>
<pre>| Claws&nbsp;&nbsp;&nbsp; | 1994-03-17 | 2003-08-19 |&nbsp;&nbsp;&nbsp; 9 |</pre>
<pre>| Fluffy&nbsp;&nbsp; | 1993-02-04 | 2003-08-19 |&nbsp;&nbsp; 10 |</pre>
<pre>| Fang&nbsp;&nbsp;&nbsp;&nbsp; | 1990-08-27 | 2003-08-19 |&nbsp;&nbsp; 12 |</pre>
<pre>| Bowser&nbsp;&nbsp; | 1989-08-31 | 2003-08-19 |&nbsp;&nbsp; 13 |</pre>
<pre>| Buffy&nbsp;&nbsp;&nbsp; | 1989-05-13 | 2003-08-19 |&nbsp;&nbsp; 14 |</pre>
<pre>+----------+------------+------------+------+</pre>

可以使用一个类似的查询来确定已经死亡动物的死亡年龄。你通过检查death值是否是NULL来确定是哪些动物，然后，对于那些非NULL值的动物，需要计算出death和birth值之间的差：

<pre>mysql&gt; **SELECT name, birth, death,**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **(YEAR(death)-YEAR(birth)) - (RIGHT(death,5)&lt;RIGHT(birth,5))**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **AS age**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **FROM pet WHERE death IS NOT NULL ORDER BY age;**</pre>
<pre>+--------+------------+------------+------+</pre>
<pre>| name&nbsp;&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | age&nbsp; |</pre>
<pre>+--------+------------+------------+------+</pre>
<pre>| Bowser | 1989-08-31 | 1995-07-29 |&nbsp;&nbsp;&nbsp; 5 |</pre>
<pre>+--------+------------+------------+------+</pre>

查询使用death IS NOT NULL而非death != NULL，因为NULL是特殊的值，不能使用普通比较符来比较，以后会给出解释。参见[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.3.4.6节，&ldquo;NULL值操作&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#working-with-null "3.3.4.6.&nbsp;Working with NULL Values")。

如果你想要知道哪个动物下个月过生日，怎么办？对于这类计算，年和天是无关的，你只需要提取birth列的月份部分。**MySQL**提供几个日期部分的提取函数，例如YEAR( )、MONTH( )和DAYOFMONTH( )。在这里MONTH()是适合的函数。为了看它怎样工作，运行一个简单的查询，显示birth和MONTH(birth)的值：

<pre>mysql&gt; **SELECT name, birth, MONTH(birth) FROM pet;**</pre>
<pre>+----------+------------+--------------+</pre>
<pre>| name&nbsp;&nbsp;&nbsp;&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | MONTH(birth) |</pre>
<pre>+----------+------------+--------------+</pre>
<pre>| Fluffy&nbsp;&nbsp; | 1993-02-04 |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>| Claws&nbsp;&nbsp;&nbsp; | 1994-03-17 |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3 |</pre>
<pre>| Buffy &nbsp;&nbsp;&nbsp;| 1989-05-13 |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5 |</pre>
<pre>| Fang&nbsp;&nbsp;&nbsp;&nbsp; | 1990-08-27 |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8 |</pre>
<pre>| Bowser&nbsp;&nbsp; | 1989-08-31 |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8 |</pre>
<pre>| Chirpy&nbsp;&nbsp; | 1998-09-11 |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9 |</pre>
<pre>| Whistler | 1997-12-09 |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 12 |</pre>
<pre>| Slim&nbsp;&nbsp;&nbsp;&nbsp; | 1996-04-29 |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4 |</pre>
<pre>| Puffball | 1999-03-30 |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3 |</pre>
<pre>+----------+------------+--------------+</pre>

找出下个月生日的动物也是容易的。假定当前月是4月，那么月值是4，你可以找在5月出生的动物&nbsp;(5月)，方法是：

<pre>mysql&gt; **SELECT name, birth FROM pet WHERE MONTH(birth) = 5;**</pre>
<pre>+-------+------------+</pre>
<pre>| name&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+-------+------------+</pre>
<pre>| Buffy | 1989-05-13 |</pre>
<pre>+-------+------------+</pre>

如果当前月份是12月，就有点复杂了。你不能只把1加到月份数(12)上并寻找在13月出生的动物，因为没有这样的月份。相反，你应寻找在1月出生的动物(1月)&nbsp;。

你甚至可以编写查询，不管当前月份是什么它都能工作。采用这种方法不必在查询中使用一个特定的月份，DATE_ADD( )允许在一个给定的日期上加上时间间隔。如果在NOW( )值上加上一个月，然后用MONTH()提取月份，结果产生生日所在月份：

<pre>mysql&gt; **SELECT name, birth FROM pet**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **WHERE MONTH(birth) = MONTH(DATE_ADD(CURDATE(),INTERVAL 1 MONTH));**</pre>

完成该任务的另一个方法是加1以得出当前月份的下一个月(在使用取模函数(MOD)后，如果月份当前值是12，则&ldquo;回滚&rdquo;到值0)：

<pre>mysql&gt; **SELECT name, birth FROM pet**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **WHERE MONTH(birth) = MOD(MONTH(CURDATE()), 12) + 1;**</pre>

注意，MONTH返回在1和12之间的一个数字，且MOD(something,12)返回在0和11之间的一个数字，因此必须在MOD( )以后加1，否则我们将从11月( 11 )跳到1月(1)。

</div>
<div class="section">
<div class="titlepage">

#### <a name="working-with-null"></a>3.3.4.6.&nbsp;NULL值操作

</div>
<a class="indexterm" name="id2693076"></a><a class="indexterm" name="id2693084"></a>

NULL值可能令人感到奇怪直到你习惯它。概念上，NULL意味着&ldquo;没有值&rdquo;或&ldquo;未知值&rdquo;，且它被看作与众不同的值。为了测试NULL，你不能使用算术比较 操作符例如=、&lt;或!=。为了说明它，试试下列查询：

<pre>mysql&gt; **SELECT 1 = NULL, 1 &lt;&gt; NULL, 1 &lt; NULL, 1 &gt; NULL;**</pre>
<pre>+----------+-----------+----------+----------+</pre>
<pre>| 1 = NULL | 1 &lt;&gt; NULL | 1 &lt; NULL | 1 &gt; NULL |</pre>
<pre>+----------+-----------+----------+----------+</pre>
<pre>|&nbsp;&nbsp;&nbsp;&nbsp; NULL |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; NULL |&nbsp;&nbsp;&nbsp;&nbsp; NULL |&nbsp;&nbsp;&nbsp;&nbsp; NULL |</pre>
<pre>+----------+-----------+----------+----------+</pre>

很显然你不能通过这些比较得到有意义的结果。相反使用IS NULL和IS NOT NULL操作符：

<pre>mysql&gt; **SELECT 1 IS NULL, 1 IS NOT NULL;**</pre>
<pre>+-----------+---------------+</pre>
<pre>| 1 IS NULL | 1 IS NOT NULL |</pre>
<pre>+-----------+---------------+</pre>
<pre>|&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 0 |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>+-----------+---------------+</pre>

请注意在**MySQL**中，0或&nbsp;NULL意味着假而其它值意味着真。布尔运算的默认真值是1。

对NULL的特殊处理即是在前面的章节中，为了决定哪个动物不再是活着的，使用death IS NOT NULL而不使用death != NULL的原因。

在GROUP BY中，两个NULL值视为相同。

执行ORDER BY时，如果运行&nbsp;ORDER BY ... ASC，则NULL值出现在最前面，若运行ORDER BY ... DESC，则NULL值出现在最后面。

NULL操作的常见错误是不能在定义为NOT NULL的列内插入0或空字符串，但事实并非如此。在NULL表示"没有数值"的地方有数值。使用IS&nbsp;[NOT]&nbsp;NULL则可以很容易地进行测试，如下所示：

<pre>mysql&gt; **SELECT 0 IS NULL, 0 IS NOT NULL, '' IS NULL, '' IS NOT NULL;**</pre>
<pre>+-----------+---------------+------------+----------------+</pre>
<pre>| 0 IS NULL | 0 IS NOT NULL | '' IS NULL | '' IS NOT NULL |</pre>
<pre>+-----------+---------------+------------+----------------+</pre>
<pre>|&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 0 |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 0 |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>+-----------+---------------+------------+----------------+</pre>

因此完全可以在定义为NOT NULL的列内插入0或空字符串，实际是NOT NULL。参见[<span style="text-decoration: underline;"><span style="color: #0000ff;">A.5.3节，&ldquo;与NULL值有关的问题&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/problems.html#problems-with-null "A.5.3.&nbsp;Problems with NULL Values")。

</div>
<div class="section">
<div class="titlepage">

#### <a name="pattern-matching"></a>3.3.4.7.&nbsp;模式匹配

</div>
<a class="indexterm" name="id2736481"></a><a class="indexterm" name="id2736488"></a><a class="indexterm" name="id2736498"></a>

**MySQL**提供标准的SQL模式匹配，以及一种基于象Unix实用程序如**vi****、****grep**和**sed**的扩展正则表达式模式匹配的格式。

SQL模式匹配允许你使用<samp>&ldquo;_&rdquo;</samp>匹配任何单个字符，而<samp>&ldquo;%&rdquo;</samp>匹配任意数目字符(包括零字符)。在MySQL中，SQL的模式默认是忽略大小写的。下面给出一些例子。注意使用SQL模式时，不能使用=或!=；而应使用LIKE或NOT LIKE比较操作符。

要想找出以<samp>&ldquo;b&rdquo;</samp>开头的名字：

<pre>mysql&gt; **SELECT * FROM pet WHERE name LIKE 'b%';**</pre>
<pre>+--------+--------+---------+------+------------+------------+</pre>
<pre>| name&nbsp;&nbsp; | owner&nbsp; | species | sex&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+--------+--------+---------+------+------------+------------+</pre>
<pre>| Buffy&nbsp; | Harold | dog&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1989-05-13 | NULL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| Bowser | Diane&nbsp; | dog&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1989-08-31 | 1995-07-29 |</pre>
<pre>+--------+--------+---------+------+------------+------------+</pre>

要想找出以<samp>&ldquo;fy&rdquo;</samp>结尾的名字：

<pre>mysql&gt; **SELECT * FROM pet WHERE name LIKE '%fy';**</pre>
<pre>+--------+--------+---------+------+------------+-------+</pre>
<pre>| name&nbsp;&nbsp; | owner&nbsp; | species | sex&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death |</pre>
<pre>+--------+--------+---------+------+------------+-------+</pre>
<pre>| Fluffy | Harold | cat&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1993-02-04 | NULL&nbsp; |</pre>
<pre>| Buffy&nbsp; | Harold | dog&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1989-05-13 | NULL&nbsp; |</pre>
<pre>+--------+--------+---------+------+------------+-------+</pre>

要想找出包含<samp>&ldquo;w&rdquo;</samp>的名字：

<pre>mysql&gt; **SELECT * FROM pet WHERE name LIKE '%w%';**</pre>
<pre>+----------+-------+---------+------+------------+------------+</pre>
<pre>| name&nbsp;&nbsp;&nbsp;&nbsp; | owner | species | sex&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+----------+-------+---------+------+------------+------------+</pre>
<pre>| Claws&nbsp;&nbsp;&nbsp; | Gwen&nbsp; | cat&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1994-03-17 | NULL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| Bowser&nbsp;&nbsp; | Diane | dog&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1989-08-31 | 1995-07-29 |</pre>
<pre>| Whistler | Gwen&nbsp; | bird&nbsp;&nbsp;&nbsp; | NULL | 1997-12-09 | NULL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+----------+-------+---------+------+------------+------------+</pre>

要想找出正好包含5个字符的名字，使用<samp>&ldquo;_&rdquo;</samp>模式字符：

<pre>mysql&gt; **SELECT * FROM pet WHERE name LIKE '_____';**</pre>
<pre>+-------+--------+---------+------+------------+-------+</pre>
<pre>| name&nbsp; | owner&nbsp; | species | sex&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death |</pre>
<pre>+-------+--------+---------+------+------------+-------+</pre>
<pre>| Claws | Gwen&nbsp;&nbsp; | cat&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1994-03-17 | NULL&nbsp; |</pre>
<pre>| Buffy | Harold | dog&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1989-05-13 | NULL&nbsp; |</pre>
<pre>+-------+--------+---------+------+------------+-------+</pre>

由**<span>MySQL</span>**提供的模式匹配的其它类型是使用扩展正则表达式。当你对这类模式进行匹配测试时，使用REGEXP和NOT REGEXP操作符(或RLIKE和NOT RLIKE，它们是同义词)。

扩展正则表达式的一些字符是：

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lsquo;.&rsquo;匹配任何单个的字符。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;字符类<samp>&ldquo;[...]&rdquo;</samp>匹配在方括号内的任何字符。例如，<samp>&ldquo;[abc]&rdquo;</samp>匹配<samp>&ldquo;a&rdquo;</samp>、<samp>&ldquo;b&rdquo;</samp>或<samp>&ldquo;c&rdquo;</samp>。为了命名字符的范围，使用一个&ldquo;-&rdquo;。<samp>&ldquo;[a-z]&rdquo;</samp>匹配任何字母，而<samp>&ldquo;[0-9]&rdquo;</samp>匹配任何数字。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<samp>&ldquo;&nbsp;*&nbsp;&rdquo;</samp>匹配零个或多个在它前面的字符。例如，<samp>&ldquo;x*&rdquo;</samp>匹配任何数量的<samp>&ldquo;x&rdquo;</samp>字符，<samp>&ldquo;[0-9]*&rdquo;</samp>匹配任何数量的数字，而<samp>&ldquo;.*&rdquo;</samp>匹配任何数量的任何字符。

*   如果REGEXP模式与被测试值的任何地方匹配，模式就匹配(这不同于LIKE模式匹配，只有与整个值匹配，模式才匹配)。

*   为了定位一个模式以便它必须匹配被测试值的开始或结尾，在模式开始处使用<samp>&ldquo;^&rdquo;</samp>或<samp>在模式的结尾用&ldquo;$&rdquo;</samp>。

为了说明扩展正则表达式如何工作，下面使用REGEXP重写上面所示的LIKE查询：

为了找出以<samp>&ldquo;b&rdquo;</samp>开头的名字，使用<samp>&ldquo;^&rdquo;</samp>匹配名字的开始：

<pre>mysql&gt; **SELECT * FROM pet WHERE name REGEXP '^b';**</pre>
<pre>+--------+--------+---------+------+------------+------------+</pre>
<pre>| name&nbsp;&nbsp; | owner&nbsp; | species | sex&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+--------+--------+---------+------+------------+------------+</pre>
<pre>| Buffy&nbsp; | Harold | dog&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1989-05-13 | NULL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| Bowser | Diane&nbsp; | dog&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1989-08-31 | 1995-07-29 |</pre>
<pre>+--------+--------+---------+------+------------+------------+</pre>

如果你想强制使REGEXP比较区分大小写，使用BINARY关键字使其中一个字符串变为二进制字符串。该查询只匹配名称首字母的小写&lsquo;b&rsquo;。

<pre>mysql&gt; **SELECT * FROM pet WHERE name REGEXP BINARY '^b';**</pre>

为了找出以<samp>&ldquo;fy&rdquo;</samp>结尾的名字，使用<samp>&ldquo;$&rdquo;</samp>匹配名字的结尾：

<pre>mysql&gt; **SELECT * FROM pet WHERE name REGEXP 'fy$';**</pre>
<pre>+--------+--------+---------+------+------------+-------+</pre>
<pre>| name&nbsp;&nbsp; | owner&nbsp; | species | sex&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death |</pre>
<pre>+--------+--------+---------+------+------------+-------+</pre>
<pre>| Fluffy | Harold | cat&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1993-02-04 | NULL&nbsp; |</pre>
<pre>| Buffy&nbsp; | Harold | dog&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1989-05-13 | NULL&nbsp; |</pre>
<pre>+--------+--------+---------+------+------------+-------+</pre>

为了找出包含一个<samp>&ldquo;w&rdquo;</samp>的名字，使用以下查询：

<pre>mysql&gt; **SELECT * FROM pet WHERE name REGEXP 'w';**</pre>
<pre>+----------+-------+---------+------+------------+------------+</pre>
<pre>| name&nbsp;&nbsp;&nbsp;&nbsp; | owner | species | sex&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+----------+-------+---------+------+------------+------------+</pre>
<pre>| Claws&nbsp;&nbsp;&nbsp; | Gwen&nbsp; | cat&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1994-03-17 | NULL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| Bowser&nbsp;&nbsp; | Diane | dog&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1989-08-31 | 1995-07-29 |</pre>
<pre>| Whistler | Gwen&nbsp; | bird&nbsp;&nbsp;&nbsp; | NULL | 1997-12-09 | NULL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+----------+-------+---------+------+------------+------------+</pre>

既然如果一个正则表达式出现在值的任何地方，其模式匹配了，就不必在先前的查询中在模式的两侧放置一个通配符以使得它匹配整个值，就像你使用了一个SQL模式那样。

为了找出包含正好5个字符的名字，使用<samp>&ldquo;^&rdquo;</samp>和<samp>&ldquo;$&rdquo;</samp>匹配名字的开始和结尾，和5个<samp>&ldquo;.&rdquo;</samp>实例在两者之间：

<pre>mysql&gt; **SELECT * FROM pet WHERE name REGEXP '^.....$';**</pre>
<pre>+-------+--------+---------+------+------------+-------+</pre>
<pre>| name&nbsp; | owner&nbsp; | species | sex&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death |</pre>
<pre>+-------+--------+---------+------+------------+-------+</pre>
<pre>| Claws | Gwen&nbsp;&nbsp; | cat&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1994-03-17 | NULL&nbsp; |</pre>
<pre>| Buffy | Harold | dog&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1989-05-13 | NULL&nbsp; |</pre>
<pre>+-------+--------+---------+------+------------+-------+</pre>

你也可以使用<samp>&ldquo;{n}&rdquo;</samp>&ldquo;重复n次&rdquo;操作符重写前面的查询：

<pre>mysql&gt; **SELECT * FROM pet WHERE name REGEXP '^.{5}$';**</pre>
<pre>+-------+--------+---------+------+------------+-------+</pre>
<pre>| name&nbsp; | owner&nbsp; | species | sex&nbsp; | birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | death |</pre>
<pre>+-------+--------+---------+------+------------+-------+</pre>
<pre>| Claws | Gwen&nbsp;&nbsp; | cat&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | 1994-03-17 | NULL&nbsp; |</pre>
<pre>| Buffy | Harold | dog&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; | 1989-05-13 | NULL&nbsp; |</pre>
<pre>+-------+--------+---------+------+------------+-------+</pre>

[<span style="text-decoration: underline;"><span style="color: #0000ff;">附录G：</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/regexp.html)[_<span style="text-decoration: underline;"><span style="color: #0000ff;">MySQL正则表达式</span></span>_](http://dev.mysql.com/doc/refman/5.1/zh/regexp.html "Appendix&nbsp;G.&nbsp;MySQL Regular Expressions")&nbsp;提供了关于正则表达式的句法的详细信息。

</div>
<div class="section">
<div class="titlepage">

#### <a name="counting-rows"></a>3.3.4.8.&nbsp;计数行

</div>
<a class="indexterm" name="id2737005"></a><a class="indexterm" name="id2737015"></a><a class="indexterm" name="id2737025"></a></div>
<div class="section">
<div class="titlepage">数据库经常用于回答这个问题，&ldquo;某个类型的数据在表中出现的频度?&rdquo;例如，你可能想要知道你有多少宠物，或每位主人有多少宠物，或你可能想要对你的动物进行各种类型的普查。

计算你拥有动物的总数目与&ldquo;在pet表中有多少行?&rdquo;是同样的问题，因为每个宠物有一个记录。COUNT(*)函数计算行数，所以计算动物数目的查询应为：

<pre>mysql&gt; **SELECT COUNT(*) FROM pet;**</pre>
<pre>+----------+</pre>
<pre>| COUNT(*) |</pre>
<pre>+----------+</pre>
<pre>|&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9 |</pre>
<pre>+----------+</pre>

在前面，你检索了拥有宠物的人的名字。如果你想要知道每个主人有多少宠物，你可以使用COUNT( )函数：

<pre>mysql&gt; **SELECT owner, COUNT(*) FROM pet GROUP BY owner;**</pre>
<pre>+--------+----------+</pre>
<pre>| owner&nbsp; | COUNT(*) |</pre>
<pre>+--------+----------+</pre>
<pre>| Benny&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>| Diane&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>| Gwen&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3 |</pre>
<pre>| Harold |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>+--------+----------+</pre>

注意，使用GROUP BY对每个owner的所有记录分组，没有它，你会得到错误消息：

<pre>mysql&gt; **SELECT owner, COUNT(*) FROM pet;**</pre>
<pre>ERROR 1140 (42000): Mixing of GROUP columns (MIN(),MAX(),COUNT(),...) </pre>
<pre>with no GROUP columns is illegal if there is no GROUP BY clause</pre>

COUNT( )和GROUP BY以各种方式分类你的数据。下列例子显示出进行动物普查操作的不同方式。

每种动物的数量：

<pre>mysql&gt; **SELECT species, COUNT(*) FROM pet GROUP BY species;**</pre>
<pre>+---------+----------+</pre>
<pre>| species | COUNT(*) |</pre>
<pre>+---------+----------+</pre>
<pre>| bird&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>| cat&nbsp;&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>| dog&nbsp;&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3 |</pre>
<pre>| hamster |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| snake&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>+---------+----------+</pre>

每种性别的动物数量：

<pre>mysql&gt; **SELECT sex, COUNT(*) FROM pet GROUP BY sex;**</pre>
<pre>+------+----------+</pre>
<pre>| sex&nbsp; | COUNT(*) |</pre>
<pre>+------+----------+</pre>
<pre>| NULL |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| f&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4 |</pre>
<pre>| m&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4 |</pre>
<pre>+------+----------+</pre>

（在这个输出中，NULL表示&ldquo;未知性别&rdquo;。）

按种类和性别组合的动物数量：

<pre>mysql&gt; **SELECT species, sex, COUNT(*) FROM pet GROUP BY species, sex;**</pre>
<pre>+---------+------+----------+</pre>
<pre>| species | sex&nbsp; | COUNT(*) |</pre>
<pre>+---------+------+----------+</pre>
<pre>| bird&nbsp;&nbsp;&nbsp; | NULL |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| bird&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| cat&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| cat&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| dog&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| dog&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>| hamster | f&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| snake&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;1 |</pre>
<pre>+---------+------+----------+</pre>

若使用COUNT( )，你不必检索整个表。例如,&nbsp;前面的查询，当只对狗和猫进行时，应为：

<pre>mysql&gt; **SELECT species, sex, COUNT(*) FROM pet**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **WHERE species = 'dog' OR species = 'cat'**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **GROUP BY species, sex;**</pre>
<pre>+---------+------+----------+</pre>
<pre>| species | sex&nbsp; | COUNT(*) |</pre>
<pre>+---------+------+----------+</pre>
<pre>| cat&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| cat&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| dog&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| dog&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>+---------+------+----------+</pre>

或，如果你仅需要知道已知性别的按性别的动物数目：

<pre>mysql&gt; **SELECT species, sex, COUNT(*) FROM pet**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **WHERE sex IS NOT NULL**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **GROUP BY species, sex;**</pre>
<pre>+---------+------+----------+</pre>
<pre>| species | sex&nbsp; | COUNT(*) |</pre>
<pre>+---------+------+----------+</pre>
<pre>| bird&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| cat&nbsp;&nbsp;&nbsp;&nbsp; | f&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| cat&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| dog&nbsp;&nbsp;&nbsp; &nbsp;| f&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| dog&nbsp;&nbsp;&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>| hamster | f&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>| snake&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>+---------+------+----------+</pre>

#### <a name="multiple-tables"></a>3.3.4.9.&nbsp;使用1个以上的表
&nbsp;

</div>

<a class="indexterm" name="id2737257"></a></div>

</div>

</div>
<div class="section">
<div class="titlepage">pet表追踪你有哪个宠物。如果你想要记录其它相关信息，例如在他们一生中看兽医或何时后代出生，你需要另外的表。这张表应该像什么呢？需要：

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;它需要包含宠物名字以便你知道每个事件属于哪个动物。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;需要一个日期以便你知道事件是什么时候发生的。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;需要一个描述事件的字段。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;如果你想要对事件进行分类，则需要一个事件类型字段。

综合上述因素，event表的CREATE TABLE语句应为：

<pre>mysql&gt; **CREATE TABLE event (name VARCHAR(20), date DATE,**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **type VARCHAR(15), remark VARCHAR(255));**</pre>

对于pet表，最容易的方法是创建包含信息的用定位符分隔的文本文件来装载初始记录：

<table id="table4" border="1" cellpadding="0">
<tbody>
<tr>
<td>

**name**

</td>
<td>

**date**

</td>
<td>

**type**

</td>
<td>

**remark**

</td>
</tr>
<tr>
<td>

Fluffy

</td>
<td>

1995-05-15

</td>
<td>

litter

</td>
<td>

4 kittens, 3 female, 1 male

</td>
</tr>
<tr>
<td>

Buffy

</td>
<td>

1993-06-23

</td>
<td>

litter

</td>
<td>

5 puppies, 2 female, 3 male

</td>
</tr>
<tr>
<td>

Buffy

</td>
<td>

1994-06-19

</td>
<td>

litter

</td>
<td>

3 puppies, 3 female

</td>
</tr>
<tr>
<td>

Chirpy

</td>
<td>

1999-03-21

</td>
<td>

vet

</td>
<td>

needed beak straightened

</td>
</tr>
<tr>
<td>

Slim

</td>
<td>

1997-08-03

</td>
<td>

vet

</td>
<td>

broken rib

</td>
</tr>
<tr>
<td>

Bowser

</td>
<td>

1991-10-12

</td>
<td>

kennel

</td>
<td>

&nbsp;

</td>
</tr>
<tr>
<td>

Fang

</td>
<td>

1991-10-12

</td>
<td>

kennel

</td>
<td>

&nbsp;

</td>
</tr>
<tr>
<td>

Fang

</td>
<td>

1998-08-28

</td>
<td>

birthday

</td>
<td>

Gave him a new chew toy

</td>
</tr>
<tr>
<td>

Claws

</td>
<td>

1998-03-17

</td>
<td>

birthday

</td>
<td>

Gave him a new flea collar

</td>
</tr>
<tr>
<td>

Whistler

</td>
<td>

1998-12-09

</td>
<td>

birthday

</td>
<td>

First birthday

</td>
</tr>
</tbody>
</table>

采用如下方式装载记录：

<pre>mysql&gt; **LOAD DATA LOCAL INFILE 'event.txt' INTO TABLE event;**</pre>

根据你从已经运行在pet表上的查询中学到的，你应该能执行对event表中记录的检索；原理是一样的。但是什么时候event表本身不能回答你可能问的问题呢？

当他们有了一窝小动物时，假定你想要找出每只宠物的年龄。我们前面看到了如何通过两个日期计算年龄。event表中有母亲的生产日期，但是为了计算母亲的年龄，你需要她的出生日期，存储在pet表中。说明查询需要两个表：

<pre>mysql&gt; **SELECT pet.name,**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **(YEAR(date)-YEAR(birth)) - (RIGHT(date,5)&lt;RIGHT(birth,5)) AS age,**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **remark**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **FROM pet, event**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **WHERE pet.name = event.name AND event.type = 'litter';**</pre>
<pre>+--------+------+-----------------------------+</pre>
<pre>| name&nbsp;&nbsp; | age&nbsp; | remark&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+--------+------+-----------------------------+</pre>
<pre>| Fluffy |&nbsp;&nbsp;&nbsp; 2 | 4 kittens, 3 female, 1 male |</pre>
<pre>| Buffy&nbsp; |&nbsp;&nbsp;&nbsp; 4 | 5 puppies, 2 female, 3 male |</pre>
<pre>| Buffy&nbsp; |&nbsp;&nbsp;&nbsp; 5 | 3 puppies, 3 female&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+--------+------+-----------------------------+</pre>

关于该查询要注意的几件事情：

*   FROM子句列出两个表，因为查询需要从两个表提取信息。
*   当从多个表组合(联结)信息时，你需要指定一个表中的记录怎样能匹配其它表的记录。这很简单，因为它们都有一个name列。查询使用WHERE子句基于name值来匹配2个表中的记录。
*   因为name列出现在两个表中，当引用列时，你一定要指定哪个表。把表名附在列名前即可以实现。

你不必有2个不同的表来进行联结。如果你想要将一个表的记录与同一个表的其它记录进行比较，可以将一个表联结到自身。例如，为了在你的宠物之中繁殖配偶，你可以用pet联结自身来进行相似种类的雄雌配对：

&nbsp;

<pre>mysql&gt; **SELECT p1.name, p1.sex, p2.name, p2.sex, p1.species**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **FROM pet AS p1, pet AS p2**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **WHERE p1.species = p2.species AND p1.sex = 'f' AND p2.sex = 'm';**</pre>
<pre>+--------+------+--------+------+---------+</pre>
<pre>| name&nbsp;&nbsp; | sex&nbsp; | name&nbsp;&nbsp; | sex&nbsp; | species |</pre>
<pre>+--------+------+--------+------+---------+</pre>
<pre>| Fluffy | f&nbsp;&nbsp;&nbsp; | Claws&nbsp; | m&nbsp;&nbsp;&nbsp; | cat&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| Buffy&nbsp; | f&nbsp;&nbsp;&nbsp; | Fang&nbsp;&nbsp; | m&nbsp;&nbsp;&nbsp; | dog&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| Buffy&nbsp; | f&nbsp;&nbsp;&nbsp; | Bowser | m&nbsp;&nbsp;&nbsp; | dog&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+--------+------+--------+------+---------+</pre>

在这个查询中，我们为表名指定别名以便能引用列并且使得每一个列引用与哪个表实例相关联更直观。

## <a name="getting-information"></a>3.4.&nbsp;获得数据库和表的信息

</div>
<a class="indexterm" name="id2737770"></a><a class="indexterm" name="id2737780"></a><a class="indexterm" name="id2737790"></a></div>
<div class="section">
<div class="titlepage">如果你忘记数据库或表的名字，或给定的表的结构是什么(例如，它的列叫什么)，怎么办？**MySQL**通过提供数据库及其支持的表的信息的几个语句解决这个问题。

你已经见到了SHOW DATABASES，它列出由服务器管理的数据库。为了找出当前选择了哪个数据库，使用DATABASE( )函数：

<pre>mysql&gt; **SELECT DATABASE();**</pre>
<pre>+------------+</pre>
<pre>| DATABASE() |</pre>
<pre>+------------+</pre>
<pre>| menagerie&nbsp; |</pre>
<pre>+------------+</pre>

如果你还没选择任何数据库，结果是NULL。

为了找出当前的数据库包含什么表(例如，当你不能确定一个表的名字)，使用这个命令：

<pre>mysql&gt; **SHOW TABLES;**</pre>
<pre>+---------------------+</pre>
<pre>| Tables in menagerie |</pre>
<pre>+---------------------+</pre>
<pre>| event&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| pet&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+---------------------+</pre>

如果你想要知道一个表的结构，可以使用DESCRIBE命令；它显示表中每个列的信息：

<pre>mysql&gt; **DESCRIBE pet;**</pre>
<pre>+---------+-------------+------+-----+---------+-------+</pre>
<pre>| Field&nbsp;&nbsp; | Type&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | Null | Key | Default | Extra |</pre>
<pre>+---------+-------------+------+-----+---------+-------+</pre>
<pre>| name&nbsp;&nbsp;&nbsp; | varchar(20) | YES&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; | NULL&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| owner&nbsp;&nbsp; | varchar(20) | YES&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; | NULL&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| species | varchar(20) | YES&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; | NULL&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;|</pre>
<pre>| sex&nbsp;&nbsp;&nbsp;&nbsp; | char(1)&nbsp;&nbsp;&nbsp;&nbsp; | YES&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; | NULL&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| birth&nbsp;&nbsp; | date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | YES&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; | NULL&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| death&nbsp;&nbsp; | date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | YES&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; | NULL&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+---------+-------------+------+-----+---------+-------+</pre>

Field显示列名字，Type是列的数据类型，Null表示列是否能包含NULL值，Key显示列是否被索引而Default指定列的默认值。

如果表有索引，SHOW INDEX FROM tbl_name生成有关索引的信息。

## <a name="batch-mode"></a>3.5.&nbsp;在批处理模式**下使用my**sql

</div>
<a class="indexterm" name="id2737935"></a><a class="indexterm" name="id2737945"></a><a class="indexterm" name="id2737952"></a><a class="indexterm" name="id2737962"></a><a class="indexterm" name="id2737969"></a></div>
<div class="section">
<div class="titlepage">在前面的章节中，你交互式地使用**mysql**输入查询并且查看结果。你也可以以批模式运行**mysql**。为了做到这些，把你想要运行的命令放在一个文件中，然后告诉**mysql**从文件读取它的输入：
<pre>shell&gt; **mysql &lt; _batch-file_**</pre>

如果在Windows下运行**mysql**，并且文件中有一些可以造成问题的特殊字符，可以这样操作：

<pre>C:/&gt; **mysql -e "source _batch-file_"**</pre>

如果你需要在命令行上指定连接参数，命令应为：

<pre>shell&gt; **mysql -h _host_ -u _user_ -p &lt; _batch-file_**</pre>
<pre>Enter password: ************</pre>

当这样操作**mysql**时，则创建一个脚本文件，然后执行脚本。

如果你想在语句出现错误的时候仍想继续执行脚本，则应使用--force命令行选项。

为什么要使用一个脚本？有很多原因：

*   如果你需要重复运行查询(比如说，每天或每周)，可以把它编成一个脚本，则每次执行时不必重新键入。
*   可以通过拷贝并编辑脚本文件从类似的现有的查询生成一个新查询。
*   当你正在开发查询时，批模式也是很有用的，特别对多行命令或多语句命令序列。如果你犯了一个错误，你不必重新输入所有内容，只需要编辑脚本来改正错误，然后告诉**mysql**再次执行脚本。
*   如果你有一个产生多个输出的查询，你可以通过一个分页器而不是盯着它翻屏到屏幕的顶端来运行输出：
<pre>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; shell&gt;** mysql &lt; batch-file | more**</pre>

*   你可以捕捉文件中的输出以便进行进一步的处理：
<pre>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; shell&gt;** mysql &lt; batch-file &gt; mysql.out**</pre>

*   你可以将脚本分发给另外的人，以便他们也能运行命令。
*   某些情况不允许交互地使用，例如,&nbsp;当你从一个**cron**任务中运行查询时。在这种情况下，你必须使用批模式。

当你以批模式运行mysql时，比起你交互地使用它时，其默认输出格式是不同的(更简明些)。例如，当交互式运行SELECT DISTINCT species FROM pet时，输出应为：

&nbsp;

<pre>+---------+</pre>
<pre>| species |</pre>
<pre>+---------+</pre>
<pre>| bird&nbsp;&nbsp;&nbsp; |</pre>
<pre>| cat&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| dog&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| hamster |</pre>
<pre>| snake&nbsp;&nbsp; |</pre>
<pre>+---------+</pre>

但是当以批模式运行时，输出应为：

<pre>species</pre>
<pre>bird</pre>
<pre>cat</pre>
<pre>dog</pre>
<pre>hamster</pre>
<pre>snake</pre>

如果你想要在批模式中得到交互输出格式，使用mysql -t。为了回显以输出被执行的命令，使用mysql -vvv。

你还可以使用源代码或&nbsp;/.命令从**mysql**提示符运行脚本：

<pre>mysql&gt; **source filename;**</pre>
<pre>mysql&gt; **/. filename**</pre>

## <a name="examples"></a>3.6.&nbsp;常用查询的例子

</div>
<div class="toc"><dl><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.1\. 列的最大值</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#example-maximum-column)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.2\. 拥有某个列的最大值的行</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#example-maximum-row)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.3\. 列的最大值：按组</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#example-maximum-column-group)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.4\. 拥有某个字段的组间最大值的行</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#example-maximum-column-group-row)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.5\. 使用用户变量</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#example-user-variables)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.6\. 使用外键</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#example-foreign-keys)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.7\. 根据两个键搜索</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#searching-on-two-keys)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.8\. 根据天计算访问量</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#calculating-days)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.6.9\. 使用AUTO_INCREMENT</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#example-auto-increment)</span></dt></dl></div>
<a class="indexterm" name="id2738257"></a><a class="indexterm" name="id2738267"></a>

下面是一些学习如何用**MySQL**解决一些常见问题的例子。

在一些例子中，使用数据库表&ldquo;shop&rdquo;来储存某个商人（经销商）的每件物品(物品号)的价格。假定每个商人对每项物品有一个固定价格，那么(物品，商人)即为该记录的主关键字。

启动命令行工具**mysql**并选择数据库：

<pre>shell&gt; **mysql _your-database-name_**</pre>

（在大多数MySQL中，你可以使用test数据库）。

你可以使用以下语句创建示例表：

<pre>mysql&gt; **CREATE TABLE shop (**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **article INT(4) UNSIGNED ZEROFILL DEFAULT '0000' NOT NULL,**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **dealer&nbsp; CHAR(20)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; DEFAULT ''&nbsp;&nbsp;&nbsp;&nbsp; NOT NULL,**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **price&nbsp;&nbsp; DOUBLE(16,2)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; DEFAULT '0.00' NOT NULL,**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **PRIMARY KEY(article, dealer));**</pre>
<pre>mysql&gt; **INSERT INTO shop VALUES**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **(1,'A',3.45),(1,'B',3.99),(2,'A',10.99),(3,'B',1.45),**</pre>
<pre>&nbsp;&nbsp;&nbsp; -&gt; **(3,'C',1.69),(3,'D',1.25),(4,'D',19.95);**</pre>

执行语句后，表应包含以下内容：

<pre>mysql&gt; **SELECT * FROM shop;**</pre>
<pre>+---------+--------+-------+</pre>
<pre>| article | dealer | price |</pre>
<pre>+---------+--------+-------+</pre>
<pre>|&nbsp;&nbsp;&nbsp; 0001 | A&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |&nbsp; 3.45 |</pre>
<pre>|&nbsp;&nbsp;&nbsp; 0001 | B&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |&nbsp; 3.99 |</pre>
<pre>|&nbsp;&nbsp;&nbsp; 0002 | A&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 10.99 |</pre>
<pre>| &nbsp;&nbsp;&nbsp;0003 | B&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |&nbsp; 1.45 |</pre>
<pre>|&nbsp;&nbsp;&nbsp; 0003 | C&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |&nbsp; 1.69 |</pre>
<pre>|&nbsp;&nbsp;&nbsp; 0003 | D&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |&nbsp; 1.25 |</pre>
<pre>|&nbsp;&nbsp;&nbsp; 0004 | D&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 19.95 |</pre>
<pre>+---------+--------+-------+</pre>
<div class="section">
<div class="titlepage">

### <a name="example-maximum-column"></a>3.6.1.&nbsp;列的最大值

</div>

&ldquo;最大的物品号是什么？&rdquo;

<pre name="code" class="programlisting">SELECT MAX(article) AS article FROM shop;

+---------+
| article |
+---------+
|       4 |
+---------+
</pre>
</div>
<div class="section">
<div class="titlepage">

### <a name="example-maximum-row"></a>3.6.2.&nbsp;拥有某个列的最大值的行

</div>
</div>
<div class="section">
<div class="titlepage">_任务：找出最贵物品的编号、销售商和价格。_

这很容易用一个子查询做到：

<pre>SELECT article, dealer, price</pre>
<pre>FROM&nbsp;&nbsp; shop</pre>
<pre>WHERE&nbsp; price=(SELECT MAX(price) FROM shop);</pre>

另一个解决方案是按价格降序排序所有行并用**MySQL**特定LIMIT子句只得到第一行：

<pre>SELECT article, dealer, price</pre>
<pre>FROM shop</pre>
<pre>ORDER BY price DESC</pre>
<pre>LIMIT 1;</pre>

**注**:如果有多项最贵的物品(&nbsp;例如每个的价格为19.95)，LIMIT解决方案仅仅显示其中一个！

### <a name="example-maximum-column-group"></a>3.6.3.&nbsp;列的最大值：按组

</div>

_任务：每项物品的的最高价格是多少？_

<pre name="code" class="programlisting">SELECT article, MAX(price) AS price
FROM   shop
GROUP BY article

+---------+-------+
| article | price |
+---------+-------+
|    0001 |  3.99 |
|    0002 | 10.99 |
|    0003 |  1.69 |
|    0004 | 19.95 |
+---------+-------+
</pre>
</div>
<div class="section">
<div class="titlepage">

### <a name="example-maximum-column-group-row"></a>3.6.4.&nbsp;拥有某个字段的组间最大值的行

</div>

_任务：对每项物品，找出最贵价格的物品的经销商。_

可以用这样一个子查询解决该问题：

<pre name="code" class="programlisting">SELECT article, dealer, price
FROM   shop s1
WHERE  price=(SELECT MAX(s2.price)
              FROM shop s2
              WHERE s1.article = s2.article);
</pre>
</div>
<div class="section">
<div class="titlepage">

### <a name="example-user-variables"></a>3.6.5.&nbsp;使用用户变量

</div>

你可以清空MySQL用户变量以记录结果，不必将它们保存到客户端的临时变量中。（参见&nbsp;[<span style="text-decoration: underline;"><span style="color: #0000ff;">9.3节，&ldquo;用户变量&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/language-structure.html#variables "9.3.&nbsp;User Variables").）。

例如，要找出价格最高或最低的物品的，其方法是：

<pre name="code" class="programlisting">mysql&gt; **SELECT @min_price:=MIN(price),@max_price:=MAX(price) FROM shop;**
mysql&gt; **SELECT * FROM shop WHERE price=@min_price OR price=@max_price;**
+---------+--------+-------+
| article | dealer | price |
+---------+--------+-------+
|    0003 | D      |  1.25 |
|    0004 | D      | 19.95 |
+---------+--------+-------+
</pre>
</div>
<div class="section">
<div class="titlepage">

### <a name="example-foreign-keys"></a>3.6.6.&nbsp;使用外键

</div>
<a class="indexterm" name="id2738582"></a><a class="indexterm" name="id2738589"></a>

在MySQL中，InnoDB表支持对外部关键字约束条件的检查。参见[<span style="text-decoration: underline;"><span style="color: #0000ff;">15.2节，&ldquo;InnoDB存储引擎&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/storage-engines.html#innodb "15.2.&nbsp;The InnoDB Storage Engine")。还可以参见[<span style="text-decoration: underline;"><span style="color: #0000ff;">1.8.5.5节，&ldquo;外键&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/introduction.html#ansi-diff-foreign-keys "1.8.5.5.&nbsp;Foreign Keys")。

只是联接两个表时，不需要外部关键字。对于除InnoDB类型的表，当使用REFERENCES&nbsp;_tbl_name_(_col_name_)子句定义列时可以使用外部关键字，该子句没有实际的效果，_只作为备忘录或注释来提醒，你目前正定义的列指向另一个表中的一个列。_执行该语句时，实现下面很重要：

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;MySQL不执行表_tbl_name_&nbsp;中的动作，例如作为你正定义的表中的行的动作的响应而删除行；换句话说，该句法不会致使ON DELETE或ON UPDATE行为（如果你在REFERENCES子句中写入ON DELETE或ON UPDATE子句，将被忽略）。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;该句法可以创建一个_column_；但不创建任何索引或关键字。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;如果用该句法定义InnoDB表，将会导致错误。

你可以使用作为联接列创建的列，如下所示：

<pre>CREATE TABLE person (</pre>
<pre>&nbsp;&nbsp;&nbsp; id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,</pre>
<pre>&nbsp;&nbsp;&nbsp; name CHAR(60) NOT NULL,</pre>
<pre>&nbsp;&nbsp;&nbsp; PRIMARY KEY (id)</pre>
<pre>);</pre>
<pre>&nbsp;</pre>
<pre>CREATE TABLE shirt (</pre>
<pre>&nbsp;&nbsp;&nbsp; id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,</pre>
<pre>&nbsp;&nbsp;&nbsp; style ENUM('t-shirt', 'polo', 'dress') NOT NULL,</pre>
<pre>&nbsp;&nbsp;&nbsp; color ENUM('red', 'blue', 'orange', 'white', 'black') NOT NULL,</pre>
<pre>&nbsp;&nbsp;&nbsp; owner SMALLINT UNSIGNED NOT NULL REFERENCES person(id),</pre>
<pre>&nbsp;&nbsp;&nbsp; PRIMARY KEY (id)</pre>
<pre>);</pre>
<pre>&nbsp;</pre>
<pre>INSERT INTO person VALUES (NULL, 'Antonio Paz');</pre>
<pre>&nbsp;</pre>
<pre>SELECT @last := LAST_INSERT_ID();</pre>
<pre>&nbsp;</pre>
<pre>INSERT INTO shirt VALUES</pre>
<pre>(NULL, 'polo', 'blue', @last),</pre>
<pre>(NULL, 'dress', 'white', @last),</pre>
<pre>(NULL, 't-shirt', 'blue', @last);</pre>
<pre>&nbsp;</pre>
<pre>INSERT INTO person VALUES (NULL, 'Lilliana Angelovska');</pre>
<pre>&nbsp;</pre>
<pre>SELECT @last := LAST_INSERT_ID();</pre>
<pre>&nbsp;</pre>
<pre>INSERT INTO shirt VALUES</pre>
<pre>(NULL, 'dress', 'orange', @last),</pre>
<pre>(NULL, 'polo', 'red', @last),</pre>
<pre>(NULL, 'dress', 'blue', @last),</pre>
<pre>(NULL, 't-shirt', 'white', @last);</pre>
<pre>&nbsp;</pre>
<pre>SELECT * FROM person;</pre>
<pre>+----+---------------------+</pre>
<pre>| id | name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>+----+---------------------+</pre>
<pre>|&nbsp; 1 | Antonio Paz&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>|&nbsp; 2 | Lilliana Angelovska |</pre>
<pre>+----+---------------------+</pre>
<pre>&nbsp;</pre>
<pre>SELECT * FROM shirt;</pre>
<pre>+----+---------+--------+-------+</pre>
<pre>| id | style&nbsp;&nbsp; | color&nbsp; | owner |</pre>
<pre>+----+---------+--------+-------+</pre>
<pre>|&nbsp; 1 | polo&nbsp;&nbsp;&nbsp; | blue&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>|&nbsp; 2 | dress&nbsp;&nbsp; | white&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>|&nbsp; 3 | t-shirt | blue&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; 1 |</pre>
<pre>|&nbsp; 4 | dress&nbsp;&nbsp; | orange |&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>|&nbsp; 5 | polo&nbsp;&nbsp;&nbsp; | red&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>|&nbsp; 6 | dress&nbsp;&nbsp; | blue&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>|&nbsp; 7 | t-shirt | white&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>+----+---------+--------+-------+</pre>
<pre>&nbsp;</pre>
<pre>&nbsp;</pre>
<pre>SELECT s.* FROM person p, shirt s</pre>
<pre> WHERE p.name LIKE 'Lilliana%'</pre>
<pre>&nbsp;&nbsp; AND s.owner = p.id</pre>
<pre>&nbsp;&nbsp; AND s.color &lt;&gt; 'white';</pre>
<pre>&nbsp;</pre>
<pre>+----+-------+--------+-------+</pre>
<pre>| id | style | color&nbsp; | owner |</pre>
<pre>+----+-------+--------+-------+</pre>
<pre>|&nbsp; 4 | dress | orange |&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>|&nbsp; 5 | polo&nbsp; | red&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>|&nbsp; 6 | dress | blue&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>+----+-------+--------+-------+</pre>

按照这种方式使用，REFERENCES子句不会显示在SHOW CREATE TABLE或DESCRIBE的输出中:

<pre>SHOW CREATE TABLE shirt/G</pre>
<pre>*************************** 1\. row ***************************</pre>
<pre>Table: shirt</pre>
<pre>Create Table: CREATE TABLE `shirt` (</pre>
<pre>`id` smallint(5) unsigned NOT NULL auto_increment,</pre>
<pre>`style` enum('t-shirt','polo','dress') NOT NULL,</pre>
<pre>`color` enum('red','blue','orange','white','black') NOT NULL,</pre>
<pre>`owner` smallint(5) unsigned NOT NULL,</pre>
<pre>PRIMARY KEY&nbsp; (`id`)</pre>
<pre>) ENGINE=MyISAM DEFAULT CHARSET=latin1</pre>

在列定义中，按这种方式使用REFERENCES作为注释或&ldquo;提示&rdquo;适用于表MyISAM和BerkeleyDB。

</div>
<div class="section">
<div class="titlepage">

### <a name="searching-on-two-keys"></a>3.6.7.&nbsp;根据两个键搜索

</div>
<a class="indexterm" name="id2738847"></a><a class="indexterm" name="id2738856"></a><a class="indexterm" name="id2738865"></a><a class="indexterm" name="id2738875"></a>

可以充分利用使用单关键字的OR子句，如同AND的处理。

一个比较灵活的例子是寻找两个通过OR组合到一起的关键字：

<pre>SELECT field1_index, field2_index FROM test_table</pre>
<pre>WHERE field1_index = '1' OR&nbsp; field2_index = '1'</pre>

该情形是已经优化过的。参见[<span style="text-decoration: underline;"><span style="color: #0000ff;">7.2.6节，&ldquo;索引合并优化&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/optimization.html#index-merge-optimization "7.2.6.&nbsp;Index Merge Optimization")。

还可以使用UNION将两个单独的SELECT语句的输出合成到一起来更有效地解决该问题。参见[<span style="text-decoration: underline;"><span style="color: #0000ff;">13.2.7.2节，&ldquo;UNION语法
&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/sql-syntax.html#union "13.2.7.2.&nbsp;UNION Syntax")。

每个SELECT只搜索一个关键字，可以进行优化：

<pre>SELECT field1_index, field2_index</pre>
<pre>&nbsp;&nbsp;&nbsp; FROM test_table WHERE field1_index = '1'</pre>
<pre>UNION</pre>
<pre>SELECT field1_index, field2_index</pre>
<pre>&nbsp; &nbsp;&nbsp;FROM test_table WHERE field2_index = '1';</pre>
</div>
<div class="section">
<div class="titlepage">

### <a name="calculating-days"></a>3.6.8.&nbsp;根据天计算访问量

</div>
<a class="indexterm" name="id2738963"></a><a class="indexterm" name="id2738972"></a><a class="indexterm" name="id2738981"></a><a class="indexterm" name="id2738990"></a>

下面的例子显示了如何使用位组函数来计算每个月中用户访问网页的天数。

<pre>CREATE TABLE t1 (year YEAR(4), month INT(2) UNSIGNED ZEROFILL,</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; day INT(2) UNSIGNED ZEROFILL);</pre>
<pre>INSERT INTO t1 VALUES(2000,1,1),(2000,1,20),(2000,1,30),(2000,2,2),</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (2000,2,23),(2000,2,23);</pre>

示例表中含有代表用户访问网页的年－月－日值。可以使用以下查询来确定每个月的访问天数：

<pre>SELECT year,month,BIT_COUNT(BIT_OR(1&lt;&lt;day)) AS days FROM t1</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; GROUP BY year,month;</pre>

将返回：

<pre>+------+-------+------+</pre>
<pre>| year | month | days |</pre>
<pre>+------+-------+------+</pre>
<pre>| 2000 |&nbsp;&nbsp;&nbsp; 01 |&nbsp;&nbsp;&nbsp; 3 |</pre>
<pre>| 2000 |&nbsp;&nbsp;&nbsp; 02 |&nbsp;&nbsp;&nbsp; 2 |</pre>
<pre>+------+-------+------+</pre>

该查询计算了在表中按年/月组合的不同天数，可以自动去除重复的询问。

</div>
<div class="section">
<div class="titlepage">

### <a name="example-auto-increment"></a>3.6.9.&nbsp;使用AUTO_INCREMENT

</div>
<a class="indexterm" name="id2739065"></a><a class="indexterm" name="id2739072"></a><a class="indexterm" name="id2739079"></a>

可以通过AUTO_INCREMENT属性为新的行产生唯一的标识：

<pre>CREATE TABLE animals (</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp; id MEDIUMINT NOT NULL AUTO_INCREMENT,</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp; name CHAR(30) NOT NULL,</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp; PRIMARY KEY (id)</pre>
<pre> );</pre>
<pre>&nbsp;</pre>
<pre>INSERT INTO animals (name) VALUES </pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;('dog'),('cat'),('penguin'),</pre>
<pre>&nbsp;&nbsp;&nbsp; ('lax'),('whale'),('ostrich');</pre>
<pre>&nbsp;</pre>
<pre>SELECT * FROM animals;</pre>

将返回：

<pre>+----+---------+</pre>
<pre>| id | name&nbsp;&nbsp;&nbsp; |</pre>
<pre>+----+---------+</pre>
<pre>|&nbsp; 1 | dog&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>|&nbsp; 2 | cat&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>|&nbsp; 3 | penguin |</pre>
<pre>|&nbsp; 4 | lax&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>|&nbsp; 5 | whale&nbsp;&nbsp; |</pre>
<pre>|&nbsp; 6 | ostrich |</pre>
<pre>+----+---------+</pre>

你可以使用LAST_INSERT_ID()SQL函数或mysql_insert_id()&nbsp;C API函数来查询最新的AUTO_INCREMENT值。这些函数与具体连接有关，因此其返回值不会被其它执行插入功能的连接影响。

**注释：**对于多行插入，LAST_INSERT_ID()和mysql_insert_id()从插入的第一行实际返回AUTO_INCREMENT关键字。在复制设置中，通过该函数可以在其它服务器上正确复制多行插入。

对于MyISAM和BDB表，你可以在第二栏指定AUTO_INCREMENT以及多列索引。此时，AUTO_INCREMENT列生成的值的计算方法为：MAX(_auto_increment_column_) + 1 WHERE prefix=_given-prefix_。如果想要将数据放入到排序的组中可以使用该方法。

<pre>CREATE TABLE animals (</pre>
<pre>&nbsp;&nbsp;&nbsp; grp ENUM('fish','mammal','bird') NOT NULL,</pre>
<pre>&nbsp;&nbsp;&nbsp; id MEDIUMINT NOT NULL AUTO_INCREMENT,</pre>
<pre>&nbsp;&nbsp;&nbsp; name CHAR(30) NOT NULL,</pre>
<pre>&nbsp;&nbsp;&nbsp; PRIMARY KEY (grp,id)</pre>
<pre>);</pre>
<pre>&nbsp;</pre>
<pre>INSERT INTO animals (grp,name) VALUES </pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;('mammal','dog'),('mammal','cat'),</pre>
<pre>&nbsp;&nbsp;&nbsp; ('bird','penguin'),('fish','lax'),('mammal','whale'),</pre>
<pre>&nbsp;&nbsp;&nbsp; ('bird','ostrich');</pre>
<pre>&nbsp;</pre>
<pre>SELECT * FROM animals ORDER BY grp,id;</pre>

将返回：

<pre>+--------+----+---------+</pre>
<pre>| grp&nbsp;&nbsp;&nbsp; | id | name&nbsp;&nbsp;&nbsp; |</pre>
<pre>+--------+----+---------+</pre>
<pre>| fish&nbsp;&nbsp; |&nbsp; 1 | lax&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| mammal |&nbsp; 1 | dog&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| mammal |&nbsp; 2 | cat&nbsp;&nbsp;&nbsp;&nbsp; |</pre>
<pre>| mammal |&nbsp; 3 | whale&nbsp;&nbsp; |</pre>
<pre>| bird&nbsp;&nbsp; |&nbsp; 1 | penguin |</pre>
<pre>| bird&nbsp;&nbsp; |&nbsp; 2 | ostrich |</pre>
<pre>+--------+----+---------+</pre>

请注意在这种情况下（AUTO_INCREMENT列是多列索引的一部分），如果你在任何组中删除有最大AUTO_INCREMENT值的行，将会重新用到AUTO_INCREMENT值。对于MyISAM表也如此,对于该表一般不重复使用AUTO_INCREMENT值。

如果AUTO_INCREMENT列是多索引的一部分，MySQL将使用该索引生成以AUTO_INCREMENT列开始的序列值。。例如，如果animals表含有索引PRIMARY KEY (grp, id)和INDEX(id)，MySQL生成序列值时将忽略PRIMARY KEY。结果是，该表包含一个单个的序列，而不是符合grp值的序列。

要想以AUTO_INCREMENT值开始而不是1，你可以通过CREATE TABLE或ALTER TABLE来设置该值，如下所示:

<pre>mysql&gt; **ALTER TABLE tbl AUTO_INCREMENT = 100;**</pre>

关于AUTO_INCREMENT的详细信息：

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;如何为列指定AUTO_INCREMENT属性：[<span style="text-decoration: underline;"><span style="color: #0000ff;">13.1.5节，&ldquo;CREATE TABLE语法&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/sql-syntax.html#create-table "13.1.5.&nbsp;CREATE TABLE Syntax")和&nbsp;[<span style="text-decoration: underline;"><span style="color: #0000ff;">13.1.2节，&ldquo;ALTER TABLE语法&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/sql-syntax.html#alter-table "13.1.2.&nbsp;ALTER TABLE Syntax")。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;AUTO_INCREMENT的动作取决于SQL模式：[<span style="text-decoration: underline;"><span style="color: #0000ff;">5.3.2节，&ldquo;SQL服务器模式&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/database-administration.html#server-sql-mode "5.3.2.&nbsp;The Server SQL Mode")。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;找出含有最新AUTO_INCREMENT值的行：[<span style="text-decoration: underline;"><span style="color: #0000ff;">12.1.3节，&ldquo;比较函数和操作符&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/functions.html#comparison-operators "12.1.3.&nbsp;Comparison Functions and Operators")。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;设置将用到的AUTO_INCREMENT值:&nbsp;[<span style="text-decoration: underline;"><span style="color: #0000ff;">13.5.3节，&ldquo;SET语法&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/sql-syntax.html#set-option "13.5.3.&nbsp;SET Syntax")&nbsp;。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;AUTO_INCREMENT和复制：[<span style="text-decoration: underline;"><span style="color: #0000ff;">6.7节，&ldquo;复制特性和已知问题&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/replication.html#replication-features "6.7.&nbsp;Replication Features and Known Problems").

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;AUTO_INCREMENT相关的可用于复制的Server-system变量(auto_increment_increment和auto_increment_offset)：[<span style="text-decoration: underline;"><span style="color: #0000ff;">5.3.3节，&ldquo;服务器系统变量&rdquo;</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/database-administration.html#server-system-variables "5.3.3.&nbsp;Server System Variables")。

&nbsp;

</div>
</div>
<div class="section">
<div class="titlepage">

## <a name="twin"></a>3.7.&nbsp;孪生项目的查询

</div>
<div class="toc"><dl><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.7.1\. 查找所有未分发的孪生项</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#twin-pool)</span></dt><dt><span class="section">[<span style="text-decoration: underline;"><span style="color: #0000ff;">3.7.2\. 显示孪生对状态的表</span></span>](http://dev.mysql.com/doc/refman/5.1/zh/tutorial.html#twin-event)</span></dt></dl></div>
<a class="indexterm" name="id2739467"></a><a class="indexterm" name="id2739477"></a>

这个项目是Institute of Environmental Medicine at Karolinska Institutet Stockholm&nbsp;和&nbsp;the Section on Clinical Research in Aging and Psychology at the University of Southern California的合作项目。

该项目包括筛选部分，即通过电话回访在瑞典超过&nbsp;65&nbsp;岁的所有孪生。满足某种标准的孪生进入下一阶段。在下一阶段中，医生/护士小组将访问想参加的孪生。部分检查包括物理检查和神经、心理检查、实验室试验、神经成像、心理状况评估和家族历史搜集。并且，应根据医疗和环境风险因素来搜集数据。

可从以下链接找到孪生研究的更多信息：

[<span style="text-decoration: underline;"><span style="color: #0000ff;">http://www.mep.ki.se/twinreg/index_en.html</span></span>](http://www.mep.ki.se/twinreg/index_en.html)

用一个用Perl和**MySQL**编写的web接口来管理项目的后面部分。

每天晚上所有会谈的数据被移入一个**MySQL**数据库。

<div class="section">
<div class="titlepage">

### <a name="twin-pool"></a>3.7.1.&nbsp;查找所有未分发的孪生项

</div>

下列查询用来决定谁进入项目的第二部分：

<pre name="code" class="programlisting">SELECT
    CONCAT(p1.id, p1.tvab) + 0 AS tvid,
    CONCAT(p1.christian_name, ' ', p1.surname) AS Name,
    p1.postal_code AS Code,
    p1.city AS City,
    pg.abrev AS Area,
    IF(td.participation = 'Aborted', 'A', ' ') AS A,
    p1.dead AS dead1,
    l.event AS event1,
    td.suspect AS tsuspect1,
    id.suspect AS isuspect1,
    td.severe AS tsevere1,
    id.severe AS isevere1,
    p2.dead AS dead2,
    l2.event AS event2,
    h2.nurse AS nurse2,
    h2.doctor AS doctor2,
    td2.suspect AS tsuspect2,
    id2.suspect AS isuspect2,
    td2.severe AS tsevere2,
    id2.severe AS isevere2,
    l.finish_date
FROM
    twin_project AS tp
    /* For Twin 1 */
    LEFT JOIN twin_data AS td ON tp.id = td.id
              AND tp.tvab = td.tvab
    LEFT JOIN informant_data AS id ON tp.id = id.id
              AND tp.tvab = id.tvab
    LEFT JOIN harmony AS h ON tp.id = h.id
              AND tp.tvab = h.tvab
    LEFT JOIN lentus AS l ON tp.id = l.id
              AND tp.tvab = l.tvab
    /* For Twin 2 */
    LEFT JOIN twin_data AS td2 ON p2.id = td2.id
              AND p2.tvab = td2.tvab
    LEFT JOIN informant_data AS id2 ON p2.id = id2.id
              AND p2.tvab = id2.tvab
    LEFT JOIN harmony AS h2 ON p2.id = h2.id
              AND p2.tvab = h2.tvab
    LEFT JOIN lentus AS l2 ON p2.id = l2.id
              AND p2.tvab = l2.tvab,
    person_data AS p1,
    person_data AS p2,
    postal_groups AS pg
WHERE
    /* p1 gets main twin and p2 gets his/her twin. */
    /* ptvab is a field inverted from tvab */
    p1.id = tp.id AND p1.tvab = tp.tvab AND
    p2.id = p1.id AND p2.ptvab = p1.tvab AND
    /* Just the screening survey */
    tp.survey_no = 5 AND
    /* Skip if partner died before 65 but allow emigration (dead=9) */
    (p2.dead = 0 OR p2.dead = 9 OR
     (p2.dead = 1 AND
      (p2.death_date = 0 OR
       (((TO_DAYS(p2.death_date) - TO_DAYS(p2.birthday)) / 365)
        &gt;= 65))))
    AND
    (
    /* Twin is suspect */
    (td.future_contact = 'Yes' AND td.suspect = 2) OR
    /* Twin is suspect - Informant is Blessed */
    (td.future_contact = 'Yes' AND td.suspect = 1
                               AND id.suspect = 1) OR
    /* No twin - Informant is Blessed */
    (ISNULL(td.suspect) AND id.suspect = 1
                        AND id.future_contact = 'Yes') OR
    /* Twin broken off - Informant is Blessed */
    (td.participation = 'Aborted'
     AND id.suspect = 1 AND id.future_contact = 'Yes') OR
    /* Twin broken off - No inform - Have partner */
    (td.participation = 'Aborted' AND ISNULL(id.suspect)
                                  AND p2.dead = 0))
    AND
    l.event = 'Finished'
    /* Get at area code */
    AND SUBSTRING(p1.postal_code, 1, 2) = pg.code
    /* Not already distributed */
    AND (h.nurse IS NULL OR h.nurse=00 OR h.doctor=00)
    /* Has not refused or been aborted */
    AND NOT (h.status = 'Refused' OR h.status = 'Aborted'
    OR h.status = 'Died' OR h.status = 'Other')
ORDER BY
    tvid;
</pre>

一些解释：

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CONCAT(p1.id, p1.tvab) + 0 AS tvid

我们想要在id和tvab的连接上以数字顺序排序。结果加0使得**<span>MySQL</span>**把结果变为一个数字。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;列id

这标识一对孪生。它是所有表中的一个键。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;列tvab

这标识孪生中的一个。它的值为1或2。

&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;列ptvab

这是tvab的一个逆运算。当tvab是1，它是2，反之亦然。它用来保存输入并且使**MySQL的**优化查询更容易。

这个查询表明，怎样用联结(p1和p2)从同一个表中查找表。在例子中，这被用来检查孪生的一个是否在65岁前死了。如果如此，行不返回值。

上述所有孪生信息存在于所有表中。我们对id,tvab（所有表）和id,ptvab&nbsp;(person_data)&nbsp;上采用键以使查询更快。

在我们的生产机器上(一台200MHz UltraSPARC)，这个查询返回大约&nbsp;150-200&nbsp;行并且时间不超过一秒。

<table id="table5" border="1" cellpadding="0">
<tbody>
<tr>
<td width="236">

**表**

</td>
<td width="153">

**行数**

</td>
</tr>
<tr>
<td width="236">

person_data

</td>
<td width="153">

71074

</td>
</tr>
<tr>
<td width="236">

lentus

</td>
<td width="153">

5291

</td>
</tr>
<tr>
<td width="236">

twin_project

</td>
<td width="153">

5286

</td>
</tr>
<tr>
<td width="236">

twin_data

</td>
<td width="153">

2012

</td>
</tr>
<tr>
<td width="236">

informant_data

</td>
<td width="153">

663

</td>
</tr>
<tr>
<td width="236">

harmony

</td>
<td width="153">

381

</td>
</tr>
<tr>
<td width="236">

postal_groups

</td>
<td width="153">

100

</td>
</tr>
</tbody>
</table>
</div>
<div class="section">
<div class="titlepage">

### <a name="twin-event"></a>3.7.2.&nbsp;显示孪生对状态的表

</div>
</div>
</div>
<div class="section">
<div class="titlepage">每一次会面以一个称为event的状态码结束。下面显示的查询被用来显示按事件组合的所有孪生的表。这表明多少对孪生已经完成，多少对的其中之一已完成而另一个拒绝了，等等。
<pre>SELECT</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; t1.event,</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; t2.event,</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; COUNT(*)</pre>
<pre>FROM</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; lentus AS t1,</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; lentus AS t2,</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; twin_project AS tp</pre>
<pre>WHERE</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; /* We are looking at one pair at a time */</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; t1.id = tp.id</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; AND t1.tvab=tp.tvab</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; AND t1.id = t2.id</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; /* Just the screening survey */</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; AND tp.survey_no = 5</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; /* This makes each pair only appear once */</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; AND t1.tvab='1' AND t2.tvab='2'</pre>
<pre>GROUP BY</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; t1.event, t2.event;</pre>

## <a name="apache"></a>3.8.&nbsp;与Apache一起使用MySQL

</div>
<a class="indexterm" name="id2739926"></a></div>
<div>还有一些项目，你可以从MySQL数据库鉴别用户，并且你还可以将日志文件写入MySQL数据库表。

你可以将以下内容放到Apache配置文件中，更改Apache日志格式，使MySQL更容易读取：

<pre>LogFormat /</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; "/"%h/",%{%Y%m%d%H%M%S}t,%&gt;s,/"%b/",/"%{Content-Type}o/",&nbsp; /</pre>
<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; /"%U/",/"%{Referer}i/",/"%{User-Agent}i/""</pre>

要想将该格式的日志文件装载到MySQL，你可以使用以下语句:

<pre>LOAD DATA INFILE '_/local/access_log_' INTO TABLE _tbl_name_</pre>
<pre>FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' ESCAPED BY '//'</pre>

所创建的表中的列应与写入日志文件的LogFormat行对应。

* * *

这是MySQL参考手册的翻译版本，关于MySQL参考手册，<span class="GramE">请访问</span>[<span style="text-decoration: underline;"><span style="color: #810081;">dev.mysql.com</span></span>](http://dev.mysql.com/doc/mysql/en)。 原始参考手册为英文版，与英文版参考手册相比，本翻译版可能不是最新的。

</div>