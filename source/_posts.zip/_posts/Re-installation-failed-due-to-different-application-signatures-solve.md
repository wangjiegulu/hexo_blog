---
title: 问题Re-installation failed due to different application signatures.解决
tags: []
date: 2012-05-28 09:44:00
---

进入SDK的<span>tools目录：</span>

<span><span>adb uninstall com.xxx.xxx(包名)</span></span>